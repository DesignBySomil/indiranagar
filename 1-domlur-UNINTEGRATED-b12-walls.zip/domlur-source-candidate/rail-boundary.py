import json,math
from shapely.geometry import Polygon,Point
m=json.load(open('public/data/domlur-joined.json'));rs=list(m['routes'].items());polys={n:Polygon(r['boundary']) for n,r in rs}
def height(r,x,z):
 best=(float('inf'),0)
 for a,b in zip(r['points'],r['points'][1:]):
  dx,dz=b[0]-a[0],b[1]-a[1];t=max(0,min(1,((x-a[0])*dx+(z-a[1])*dz)/(dx*dx+dz*dz)));d=math.hypot(x-a[0]-dx*t,z-a[1]-dz*t)
  if d<best[0]:best=(d,a[2]+(b[2]-a[2])*t)
 return best[1]
kept=removed=0
for name,r in rs:
 r['railSegments']=[]
 for a,b in zip(r['boundary'],r['boundary'][1:]):
  n=max(1,math.ceil(math.dist(a,b)/.5))
  for i in range(n):
   p=[a[k]+(b[k]-a[k])*i/n for k in range(2)];q=[a[k]+(b[k]-a[k])*(i+1)/n for k in range(2)];x,z=[(p[k]+q[k])/2 for k in range(2)];y=height(r,x,z)
   portal=any(math.hypot(x-e[0],z-e[1])<4 for e in [r['points'][0],r['points'][-1]])
   internal=any(polys[nn].buffer(.02).covers(Point(x,z)) and abs(height(rr,x,z)-y)<.12 for nn,rr in rs if nn!=name)
   if portal or internal:removed+=1;continue
   r['railSegments'].append([[p[0],height(r,*p),p[1]],[q[0],height(r,*q),q[1]]]);kept+=1
json.dump(m,open('public/data/domlur-joined.json','w'));print({'kept':kept,'removed':removed,'scope':'sampled rail boundary only, no collision acceptance'})
