# Unintegrated batch34: daylight facade continuity

Replaced plain window squares with flush window frames/mullions, floor bands, ground-floor shutters and roof-edge bands. All detail stays on existing source footprint planes, no new collision volume or height. Five merged detail meshes rather than per-window objects. Includes prior batch33 vegetation source/data.

Fixed-noon actual main drive, chase at650m/1000m/1200m inspected. New ground facades are more readable, but1000m view exposes an obvious transition gap: accepted street/tree furniture starts before the detailed city buildings, while candidate building rendering excludes footprints crossingZ1000. This is a known visual seam to fix, not a finished scene. No photo-real or surveyed facade claim. Test script uses real drive but suppresses render between samples; no physical-device acceptance.

No accepted source or deployment change. This local patch includes unpreserved b33; not remotely preserved yet.
