# Creative vegetation placement inside retained OSM green polygons, not a tree survey.
exec(open('scenery-land.py').read().split('by={};ids=[]')[0])
from shapely.geometry import Point,LineString
from random import Random
rng=Random(28);polys=[]
for w in m['ways']:
 t=w['tags'];kind=t.get('leisure',t.get('natural',''))
 if kind not in ['park','garden','wood','scrub']or len(w['nodes'])<4 or any(n not in m['nodes']for n in w['nodes']):continue
 p=Polygon([((m['nodes'][n][1]-lon0)*lx,(lat0-m['nodes'][n][0])*lz)for n in w['nodes']]).buffer(0).intersection(box(-800,1000,800,2250))
 if not p.is_empty:polys.append(p)
greens=unary_union(polys);buildings=json.load(open('public/data/domlur-buildings-game.json'));exclusions=[Polygon(b['points']).buffer(2)for b in buildings['buildings']]
exclusions.extend(LineString(r['p']).buffer(9)for r in m['roads']if len(r['p'])>1)
joined=json.load(open('public/data/domlur-joined.json'));exclusions.extend(LineString([(p[0],p[1])for p in r['points']]).buffer(15)for r in joined['routes'].values())
allowed=greens.difference(unary_union(exclusions));trees=[]
for x in range(-800,800,10):
 for z in range(1000,2250,10):
  xx,zz=x+rng.uniform(-3,3),z+rng.uniform(-3,3)
  if allowed.contains(Point(xx,zz))and rng.random()<.55:trees.append([round(xx,2),round(zz,2),round(rng.uniform(5,9),2)])
json.dump({'scope':'Creative vegetation in OSM green polygons. All trunks excluded >=15m from candidate route centerlines, >=9m from source roads and >=2m from buildings. Not surveyed tree locations.','trees':trees},open('public/data/domlur-vegetation.json','w'));print('trees',len(trees))
