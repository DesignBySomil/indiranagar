# Unintegrated batch 33: source-constrained vegetation

125 creative game trees inside retained OSM park/garden/wood/scrub polygons. Not surveyed tree positions. Tree centers are excluded15m from candidate route centerlines,9m from all source roads,2m from buildings. Crown maximum radius3.06m, so the candidate driving corridor and usual chase boom remain outside the trees. Two instanced meshes, not125separate tree draw objects. No new route support or building-height changes.

Actual210m elevated main-drive chase pixels inspected. Green polygons now have vegetation rather than empty land alone, but the scene still has a basic block-building look and is not claimed finished. No production/accepted source changes. Local patch, not remotely preserved yet.
