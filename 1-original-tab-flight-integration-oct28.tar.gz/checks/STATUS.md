# Isolated unaccepted original flight-physics candidate

Based on accepted commit3bcd1e7, separate from Domlur. No production promotion.

Replaces the earlier scripted hover with vertical velocity/acceleration and gravity. Tab activates once per press, powered stage4.45s aims for2.8m, followed by unpowered descent. Tests at20/30/60/120Hz land between5and6seconds without an altitude snap. Jets only visible while powered. All horizontal drive and existing collision logic remains conservative, so cars/buildings cannot be flown over. Grounded collision semantics are not replaced with free3D collision volumes.

Bridge/tree clearance query uses existing street bridgeVolumes, inflated by2.35m vehicle circumradius, with2.35m vehicle height plus.25m gap. Tests cover rectangles, polygons, edge padding and low ceilings. Destination horizontal probes reject positions where ceiling would intersect the current altitude. This does not establish complete geometry coverage or camera near-plane clearance.

Camera: extracted actual clamp reproduces stationary actor-induced pull-in/lift. Below0.15m/s camera ignores traffic/crowd obstruction; static and parked checks remain. Does not prove every idle drift cause is eliminated.

PASS: isolated vertical physics, takeoff, landing, held/repeated input, low ceilings, clearance footprint tests, extracted clamp fixture and Vite build. Open: full-game physics integration, actual rendered pixels, jet/body placement, overhead geometry coverage, airborne horizontal behavior/recovery, camera modes/blends/near-plane and physical devices. No repeated game startup made. NOT ready or accepted as the user's requested flight.

## Actual-step regression added
Extracted the actual main step through camera/hazards, with real createHazards and controlled static/mover world callbacks. Grounded420-frame traces in clear/wall/actor scenarios exactly equal accepted3bcd1e7. Flight tests cover wall, moving blocker, total overlap and low overhead entry. Airborne actor-kick dispatch suppressed; no airborne recovery timers; hazards do not trigger road resistance/splash/shake while above.12m. Existing splash particles can finish their lifetime. Controlled world callbacks do not establish actual actor geometry coverage, actual traffic simulation or all map volumes. Boundary fallback and source geometry completeness remain separate checks.
