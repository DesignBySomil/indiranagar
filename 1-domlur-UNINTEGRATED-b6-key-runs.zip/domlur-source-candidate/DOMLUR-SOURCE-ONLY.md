# SOURCE-ONLY opt-in harness, not an implemented flyover
Base: original boundary candidate 3bcd1e7f53fbcfbaf18af44d26636ff5a2598fad.
No production, accepted tree or normal-game map changes.

New QA-only load/attach entry points exercise the support adapter in a separate early-return branch. They deliberately do not integrate rendering, camera, traffic, impacts, recovery or scenery. Do not deploy this as a finished feature.

Default ground path regression: 16697 simulation steps, 31 loop nodes, 1403.662591 m travel, 0 recoveries. Full trace JSON exactly equals the accepted baseline (including all positions, velocities and metrics). This covers one loop with movers disabled, not every ground behavior.

Adapter standalone support: north4781,airport5308,south4797 samples using the existing game's seven body-probe offsets. These are not input-driven game drives. No grade pitch, dynamic collisions, branch switches or attached-road renderer yet. Game heights and width are provisional, not surveyed.

## Batch 6: key-driven harness runs
Three routes driven with dispatched W/A/D inputs in the opt-in candidate branch at about 4 m/s. Reached every route node within 1.5 m threshold: northbound 476.741 m / 7062 steps, airport-to-north 529.017 m / 7835 steps, southbound 478.366 m / 7086 steps. No support refusal (zero-speed block) in these runs. Max height change per tick <=0.01065 m. Two seconds S from final forward speed ends v=-6 and net backward signed displacement 6.695/6.817/6.719 m.
These runs use simplified opt-in dynamics and omit the main collision/recovery/camera path. They are evidence for the adapter harness, not accepted game driving or visual flyover acceptance. No physical device or browser-rendered flyover pixels validated.
