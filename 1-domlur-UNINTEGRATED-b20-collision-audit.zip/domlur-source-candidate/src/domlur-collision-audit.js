// Read-only integration audit. Never turns unknown ground-grid hits into permission.
export function auditDomlurBuildingContact(world,solid,x,z,y,roof=2.2){
 if(!solid(x,z))return{blocked:false,status:'legacy-clear',matches:[]};
 const inside=(p)=>{let yes=false;for(let i=0,j=p.length-1;i<p.length;j=i++){const a=p[i],b=p[j];if((a[1]>z)!==(b[1]>z)&&x<(b[0]-a[0])*(z-a[1])/(b[1]-a[1])+a[0])yes=!yes;}return yes;};
 const matches=world.buildings.filter(b=>b._renderedFacade&&inside(b._renderedFacade.pts)).map(b=>({min:-.12,max:b._renderedFacade.h+.12}));
 if(!matches.length)return{blocked:true,status:'unknown-grid-hit',matches};
 return{blocked:matches.some(b=>y+roof>=b.min&&y<=b.max),status:'rendered-building-interval',matches};
}
