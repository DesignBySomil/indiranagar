# Recover actual outgoing OSM way, one shared mesh and named portal.
import json,math
from shapely.geometry import LineString
from shapely.ops import triangulate
base='public/data/'
m=json.load(open('/tmp/deep-research/domlur/merged-map.json'));w=next(w for w in m['roads'] if w['id']=='1109947893')
d=json.load(open(base+'domlur-candidate.json'));d['groundPortal']={'node':'286654942','way':w['id'],'name':'north_ground','nodes':w['nodes'],'points':w['p'],'routes':['northbound','airport_to_north'],'scope':'One actual shared ground continuation; only last 89.02m to next source node, not connection to original map'}
for n,p in zip(w['nodes'],w['p']):
 if n not in d['nodes']:d['nodes'][n]={'p':p,'y':0,'branch':False,'distanceToGround':0}
json.dump(d,open(base+'domlur-candidate.json','w'))
g=json.load(open(base+'domlur-joined.json'));poly=LineString(w['p']).buffer(3.3,cap_style=1,join_style=1,quad_segs=8);pending=[list(t.exterior.coords)[:3] for t in triangulate(poly) if poly.covers(t)];fine=[]
while pending:
 t=pending.pop();i=max(range(3),key=lambda i:math.dist(t[i],t[(i+1)%3]))
 if math.dist(t[i],t[(i+1)%3])>2:
  a,b,c=t[i],t[(i+1)%3],t[(i+2)%3];mid=[(a[j]+b[j])/2 for j in range(2)];pending.extend([[a,mid,c],[mid,b,c]])
 else:fine.append([[x,0,z] for x,z in t])
# Ordinary ground continuation has no slab side-wall or flyover rails.
g['routes']['north_ground']={'points':[[*p,0]for p in w['p']],'boundary':list(poly.exterior.coords),'triangles':fine,'railSegments':[],'ground':True,'sourceWay':w['id']};json.dump(g,open(base+'domlur-joined.json','w'));print({'groundTriangles':len(fine),'sourceWay':w['id'],'length':LineString(w['p']).length})
