// Powered vertical flight. Horizontal collisions stay conservative, including traffic.
export function flightCeiling(x,z,volumes=[],bodyHeight=2.35){
  let cap=Infinity;const margin=2.35; // full vehicle circumradius, not a point probe
  const segmentDistance=(x,z,a,b)=>{const dx=b[0]-a[0],dz=b[1]-a[1],d=dx*dx+dz*dz,t=d?Math.max(0,Math.min(1,((x-a[0])*dx+(z-a[1])*dz)/d)):0;return Math.hypot(x-a[0]-dx*t,z-a[1]-dz*t);};
  for(const b of volumes){if(!Number.isFinite(b.clearanceY))continue;let under=false;
    if(b.rect){const r=b.rect,dx=x-r.x,dz=z-r.z,sy=Math.sin(r.yaw),cy=Math.cos(r.yaw);under=Math.abs(dx*sy+dz*cy)<=r.halfLen+margin&&Math.abs(dx*cy-dz*sy)<=r.halfW+margin;}
    else if(b.poly?.length>=3){for(let i=0,j=b.poly.length-1;i<b.poly.length;j=i++){const a=b.poly[i],p=b.poly[j];if((a[1]>z)!==(p[1]>z)&&x<(p[0]-a[0])*(z-a[1])/(p[1]-a[1])+a[0])under=!under;}under=under||b.poly.some((p,i)=>segmentDistance(x,z,p,b.poly[(i+1)%b.poly.length])<=margin);}
    else under=Math.hypot(x-b.x,z-b.z)<=(b.r||0)+margin;
    if(under)cap=Math.min(cap,Math.max(0,b.clearanceY-bodyHeight-.25));
  }return cap;
}
export function createThruster(){let held=false,elapsed=0,active=false,height=0,vy=0;return{
  press(){if(held)return false;held=true;if(active||height>0)return false;elapsed=0;active=true;return true;},release(){held=false;},
  update(dt,ceiling=Infinity){dt=Math.max(0,Math.min(1,dt));let flame=false,landed=false;
    // Substeps bound vertical acceleration and ceiling/ground contacts even after a slow frame.
    for(let left=dt;left>1e-9;){const h=Math.min(left,1/120);left-=h;if(!active)continue;elapsed+=h;
      const powered=elapsed<4.45;const target=Math.min(2.8,Math.max(0,ceiling));
      const acceleration=powered?Math.max(-12,Math.min(12,(target-height)*18-vy*8)):-5.2;
      vy+=acceleration*h;height+=vy*h;flame=powered&&ceiling>.05;
      if(height>ceiling){height=Math.max(0,ceiling);vy=Math.min(vy,0);}
      if(height<=0){height=0;vy=0;if(!powered||ceiling<=0){active=false;landed=true;flame=false;}}
      // Emergency bounded end. Normal flight lands near5.5s; never snap airborne to ground.
      if(elapsed>6&&height>0)vy=Math.min(vy,-1);
    }return{active,height,vy,flame:active&&flame,landed,elapsed};
  },get active(){return active;},get height(){return height;}};
}
