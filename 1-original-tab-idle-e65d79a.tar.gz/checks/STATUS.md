# Isolated unaccepted original candidate

Based on accepted commit3bcd1e7, not the Domlur branch. No production promotion.

Camera: actual extracted clamp reproduces stationary actor-induced pull-in/lift. Below0.15m/s, camera ignores dynamic traffic/crowd obstruction, while static/parked checks remain. Moving behavior unchanged in the controlled fixture. Does not prove every source of idle drift is eliminated.

Tab: 5.5-second bounded1.2m game hover prototype. Visible jets only during thrust. All ground-plane collision logic stays in effect: this is not free3D flight and cannot fly over cars/buildings. Held Tab cannot retrigger; explicit release/repress required. Tab keeps normal behavior on form controls/links/buttons.

PASS: timer/height/held-key unit tests, extracted clamp fixture, Vite build. Open: actual game pixels, jets/model placement, low overhead clearance, flight camera modes and mode blends, grounded collision/landing feel, phone behavior. Rendering remains blocked; no repeated startup attempt made. Do not present as a verified flight feature or completed fix.
