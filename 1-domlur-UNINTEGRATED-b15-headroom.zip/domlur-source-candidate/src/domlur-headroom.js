// Candidate-only body prism versus the SAME triangles rendered as 0.4m slabs.
// Body dimensions/clearance are provisional game values, not surveyed vehicle data.
export function createDomlurHeadroom(data){
 const cellSize=8,cells=new Map();let count=0;
 for(const[name,r]of Object.entries(data.routes))for(const triangle of r.triangles){
  const xs=triangle.map(p=>p[0]),zs=triangle.map(p=>p[2]);
  const t={route:name,triangle,id:count++};
  for(let x=Math.floor(Math.min(...xs)/cellSize);x<=Math.floor(Math.max(...xs)/cellSize);x++)for(let z=Math.floor(Math.min(...zs)/cellSize);z<=Math.floor(Math.max(...zs)/cellSize);z++){const key=x+','+z;if(!cells.has(key))cells.set(key,[]);cells.get(key).push(t);}
 }
 // Sutherland-Hodgman clipping retains interpolated height at each footprint vertex.
 const clip=(poly,axis,bound,sign)=>{const out=[];for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],da=sign*(a[axis]-bound),db=sign*(b[axis]-bound),ina=da>=-1e-9,inb=db>=-1e-9;if(ina)out.push(a);if(ina!==inb){const t=da/(da-db);out.push(a.map((v,j)=>v+(b[j]-v)*t));}}return out;};
 function query(x,z,y,a,{bottom=.25,roof=2.2}={}){
  const c=Math.cos(a),s=Math.sin(a),radius=2.14,seen=new Set(),hits=[];let tested=0,overhead=Infinity;
  for(let gx=Math.floor((x-radius)/cellSize);gx<=Math.floor((x+radius)/cellSize);gx++)for(let gz=Math.floor((z-radius)/cellSize);gz<=Math.floor((z+radius)/cellSize);gz++)for(const t of cells.get(gx+','+gz)||[]){if(seen.has(t.id))continue;seen.add(t.id);tested++;
   let p=t.triangle.map(v=>{const dx=v[0]-x,dz=v[2]-z;return[c*dx-s*dz,s*dx+c*dz,v[1]];});
   for(const[axis,bound,sign]of[[0,-.85,1],[0,.85,-1],[1,-1.3,1],[1,1.95,-1]]){p=clip(p,axis,bound,sign);if(!p.length)break;}
   if(p.length<3)continue;
   const min=Math.min(...p.map(v=>v[2])),max=Math.max(...p.map(v=>v[2]));
   if(min-.4>=y+bottom)overhead=Math.min(overhead,min-.4-y);
   if(min-.4<y+roof-1e-7&&max>y+bottom+1e-7)hits.push({route:t.route,triangle:t.id,minTop:min,maxTop:max});
  }
  return{blocked:hits.length>0,hits,overhead,tested};
 }
 return{query,triangles:count};
}
