import {createDomlurHeadroom} from './domlur-headroom.js';
// SOURCE-ONLY opt-in adapter. Unintegrated geometry experiment, not accepted gameplay.
export function createDomlurCandidate(data){
 const routes=Object.entries(data.routes).map(([name,r])=>{const points=r.nodes.map(n=>data.nodes[n]),segs=[];let total=0;for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],len=Math.hypot(b.p[0]-a.p[0],b.p[1]-a.p[1]);segs.push({a,b,len,s0:total});total+=len;}return{name,segs,total};});
 const project=(r,x,z)=>r.segs.map((g,i)=>{const dx=g.b.p[0]-g.a.p[0],dz=g.b.p[1]-g.a.p[1],t=Math.max(0,Math.min(1,((x-g.a.p[0])*dx+(z-g.a.p[1])*dz)/g.len**2)),px=g.a.p[0]+dx*t,pz=g.a.p[1]+dz*t;return{i,s:g.s0+t*g.len,x:px,z:pz,d:Math.hypot(x-px,z-pz),y:g.a.y+(g.b.y-g.a.y)*t,yaw:Math.atan2(dx,dz)};});
 let state=null,railData=null,headroom=null;
 function attach(name,atEnd=false){const r=routes.find(r=>r.name===name);if(!r)throw Error('unknown route');const g=atEnd?r.segs.at(-1):r.segs[0];state={route:name,s:atEnd?r.total:0};return{x:atEnd?g.b.p[0]:g.a.p[0],z:atEnd?g.b.p[1]:g.a.p[1],y:0,a:Math.atan2(g.b.p[0]-g.a.p[0],g.b.p[1]-g.a.p[1])};}
 function resolve(x,z,a,maxTravel){if(!state)return null;const r=routes.find(r=>r.name===state.route),qs=project(r,x,z).filter(q=>Math.abs(q.s-state.s)<=maxTravel+1&&q.d<=3.3);qs.sort((a,b)=>a.d-b.d);const q=qs[0];if(!q)return null;
 // Use existing game's more conservative body probe offsets, not toy rectangle size.
 for(const[lx,lz]of[[.85,1.8],[-.85,1.8],[.85,-1.3],[-.85,-1.3],[0,1.95],[0,.3],[0,-1.3]]){const px=x+Math.cos(a)*lx+Math.sin(a)*lz,pz=z-Math.sin(a)*lx+Math.cos(a)*lz;if(!project(r,px,pz).some(c=>Math.abs(c.s-q.s)<4&&c.d<=3.3))return null;}
 if(railData){const rails=railData.routes[r.name].railSegments||[];
 const c=Math.cos(a),s=Math.sin(a),body=[[-.85,-1.3],[.85,-1.3],[.85,1.95],[-.85,1.95]].map(([lx,lz])=>[x+c*lx+s*lz,z-s*lx+c*lz]);
 const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
 for(const [u,v]of rails){if(Math.abs((u[1]+v[1])/2-q.y)>1)continue;if(Math.hypot((u[0]+v[0])/2-x,(u[2]+v[2])/2-z)>4)continue;const aa=[u[0],u[2]],bb=[v[0],v[2]];for(let k=0;k<4;k++){const cc=body[k],dd=body[(k+1)%4];if(cross(aa,bb,cc)*cross(aa,bb,dd)<=0&&cross(cc,dd,aa)*cross(cc,dd,bb)<=0)return null;}}
 }
 if(headroom?.query(x,z,q.y,a).blocked)return null;
 return{...q,route:r.name};}
 return{setRails:data=>{railData=data;headroom=createDomlurHeadroom(data)},attach,resolve,commit:q=>{state={route:q.route,s:q.s};},detach:()=>{state=null;},get active(){return !!state},get state(){return state&&{...state}},routes};
}
