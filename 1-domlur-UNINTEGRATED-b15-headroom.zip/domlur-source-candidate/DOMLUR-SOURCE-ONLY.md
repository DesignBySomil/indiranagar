# SOURCE-ONLY opt-in harness, not an implemented flyover
Base: original boundary candidate 3bcd1e7f53fbcfbaf18af44d26636ff5a2598fad.
No production, accepted tree or normal-game map changes.

New QA-only load/attach entry points exercise the support adapter in a separate early-return branch. They deliberately do not integrate rendering, camera, traffic, impacts, recovery or scenery. Do not deploy this as a finished feature.

Default ground path regression: 16697 simulation steps, 31 loop nodes, 1403.662591 m travel, 0 recoveries. Full trace JSON exactly equals the accepted baseline (including all positions, velocities and metrics). This covers one loop with movers disabled, not every ground behavior.

Adapter standalone support: north4781,airport5308,south4797 samples using the existing game's seven body-probe offsets. These are not input-driven game drives. No grade pitch, dynamic collisions, branch switches or attached-road renderer yet. Game heights and width are provisional, not surveyed.

## Batch 6: key-driven harness runs
Three routes driven with dispatched W/A/D inputs in the opt-in candidate branch at about 4 m/s. Reached every route node within 1.5 m threshold: northbound 476.741 m / 7062 steps, airport-to-north 529.017 m / 7835 steps, southbound 478.366 m / 7086 steps. No support refusal (zero-speed block) in these runs. Max height change per tick <=0.01065 m. Two seconds S from final forward speed ends v=-6 and net backward signed displacement 6.695/6.817/6.719 m.
These runs use simplified opt-in dynamics and omit the main collision/recovery/camera path. They are evidence for the adapter harness, not accepted game driving or visual flyover acceptance. No physical device or browser-rendered flyover pixels validated.

## Batch 7: visual diagnostic, blocked
Added explicit-load-only three-route diagnostic renderer and simple chase pose. At ~210 m, south full post image shows auto/road in empty brown environment. Airport-to-north full post image is black. Fresh isolated Airport run: raw renderer is visible, full post remains black, so this narrows the failure to the post-render path in this candidate but does not identify its cause. Raw image also exposes an unrelated huge clipped object in sky and distant current-map boundary. No visual acceptance. No production changes. render-results.json was overwritten by the most recent diagnostic run. No complete flyover scene, rails/piers/collision/main camera integration.

## Batch 8: post-path isolation, still blocked
Same Airport pose: no AO remains black; Render+Output only visible; no bloom only visible; no grade only black; no grain only black. Therefore bloom or its inputs are implicated, root cause not known. No quality cut applied to game. Added lighting/shadow updates in opt-in harness to keep sky centered on moving auto; full post remains black. Script variants are diagnostics, not fixes. bloom-findings.json records the pass-isolation result.

## Batch 9: bounded foliage-normal guard
At exact failing Airport pose, float readback found 12 NaN channels before bloom (3 with AO off), spreading through bloom mips. Ray located flat-shaded instanced tree foliage. Candidate-only trees.js shader guards normalization of derivative cross product when squared length <=1e-20. Same-pose all-effects render: input and every bloom target now zero NaNs; full-post image visible. Does not prove map-wide/device safety. No effect disabled. Sky clipping also gone after the batch-8 missing lighting/sky-follow update. Extension remains empty diagnostic, not accepted gameplay.

## Batch 10: broader heading audit, limited fixture
Eight frames at 450x300 all have zero bloom-input NaN/Inf channels. Four original-map frames (100 Feet and curved-road area, headings 0/pi2) visually inspected, readable buildings/foliage/car, no black frame. Not an original-vs-candidate pixel equivalence test. Four extension position samples manually teleport without loading candidate road mesh or updating sky-follow; they prove finite output only, not bridge visuals. 900x600 16-frame attempt timed out; reduced batch completed. render-headings.cjs and heading-results.json preserve the fixture/results.

## Batch 11: corrected extension fixture and deterministic pair
Corrected four extension views load diagnostic road mesh and center sky: visible all-effects output, zero NaN/Inf, still empty diagnostic corridors. Unseeded baseline/guard comparisons were confounded by road random textures (mean difference 0.098-1.633/255), not treated as equivalence. Seeded Math.random fixture resolves that: four original-map baseline/guard frames at 450x300 are EXACT pixel equal, difference 0. Paired sheet visually inspected. This is bounded ordinary-view equivalence, not map-wide/physical-device proof. One seeded guard startup got local connection refusal; fresh retry completed. No accepted source/deployment change.

## Batch 12: candidate deck edge walls, unfinished
Candidate renderer adds 0.4 m side thickness and 0.65 m rail-wall surfaces (game-only choices). Four view pixels finite/visible, but main merge has remaining internal side faces. Sampled half-meter boundary filter removes 369 portal/internal rail subsegments while keeping 5869. This is not a proven height-safe polygon union, no rail collision acceptance, no piers or underside slab. Render and corridor collision are not yet one geometry. Do not deploy as drivable flyover. Only separate candidate changed.

## Batch 13: shared rail input, still not unified topology
Renderer side-wall and candidate body-edge rejection now use the same sampled railSegments (height difference <=1 m gate). Three key-driven harness routes still complete with same metrics/reverse results. Six lateral pose tests stop after 2.4 m offsets. Not swept/main-game collision and corridor support also rejects outer poses, so not isolated rail-only proof. Main merge artifacts remain visible after side-wall filtering. Proper shared topology still required. Initial visual rerun hit local connection refusal; fresh retry succeeded. No accepted source/deployment changes.

## Batch 14: corrected topology diagnosis and underside
Correction to batches 12/13 hypothesis: no main deck path is duplicated between these three routes. North/ramp share only ground endpoint 286654942. Their other plan overlap is stacked (north Y6.8 vs ramp~1.62); south/ramp overlap is stacked (Y6.8 vs~1.0, no shared node). Do NOT union these plan polygons. Added underside slab render and two underdeck views, finite and visually inspected. Visible stacked decks now explain some lower faces; still no piers, physical underdeck/headroom collision, main physics or final aesthetics. Candidate heights remain game-only. Main-carriageway visual artifacts not declared fixed. Ground shared endpoint still needs a proper portal connection.

## Batch 15: triangle-based static headroom gate
Support adapter now rejects body-prism intersections with the same 20,827 rendered 0.4 m slab triangles, clipped in body-local coordinates with interpolated heights and an 8 m spatial index. Provisional body interval is 0.25-2.2 m above support. All 14,886 route support samples pass; ramp route minimum sampled underside height above support is 4.4356 m (game geometry only). Four low crossing poses pass, while identical XZ/heading raised to Y5 are rejected by the upper slab. Independent isolated triangle overlap/miss/above/below fixtures pass. Three key-driven harness routes and reverse metrics remain unchanged with zero blocks. This is static pose rejection, not swept collision, main collision/recovery, real clearance, or complete driving acceptance. Renderer unchanged from inspected batch 14. Endpoint connection remains open.
