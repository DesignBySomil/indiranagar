# Park identity/boundary/footways are retained OSM; fixtures are game art, not a survey.
from shapely import constrained_delaunay_triangles
exec(open('scenery-land.py').read().split('by={};ids=[]')[0])
from shapely.geometry import LineString,Point
w=next(w for w in m['ways']if w['id']=='217565867')
project=lambda ns:[((m['nodes'][n][1]-lon0)*lx,(lat0-m['nodes'][n][0])*lz)for n in ns]
park=Polygon(project(w['nodes'])).buffer(0);joined=json.load(open('public/data/domlur-joined.json'));route=unary_union([LineString([(p[0],p[1])for p in r['points']]).buffer(15)for r in joined['routes'].values()]);paths=[]
for w in m['ways']:
 if w['tags'].get('highway')not in ['footway','path']or len(w['nodes'])<2 or any(n not in m['nodes']for n in w['nodes']):continue
 p=LineString(project(w['nodes'])).buffer(.8).intersection(park)
 if not p.is_empty:paths.append(p)
geom=unary_union(paths);pos=[]
for tri in constrained_delaunay_triangles(geom).geoms:
 for x,z in list(tri.exterior.coords)[:3]:pos.extend([x,.07,z])
fence=[];ring=park.exterior
for d in range(0,int(ring.length),4):
 p=ring.interpolate(d);q=ring.interpolate(min(d+4,ring.length))
 if route.distance(p)>0 and route.distance(q)>0:fence.append([p.x,p.y,q.x,q.y])
benches=[]
for d in range(12,int(ring.length),28):
 p=ring.interpolate(d);near=park.representative_point();dx, dz=near.x-p.x,near.y-p.y;L=(dx*dx+dz*dz)**.5;x,z=p.x+dx/L*4,p.y+dz/L*4
 if park.contains(Point(x,z))and not route.contains(Point(x,z)):benches.append([x,z,0])
json.dump({'scope':'Domlur SAARC Park OSM way217565867 and source footways. Fences/benches are creative game fixtures excluded15m from candidate routes, not surveyed.','sourceWay':'217565867','paths':pos,'fence':fence,'benches':benches},open('public/data/domlur-park.json','w'));print('paths',len(pos)//9,'fence',len(fence),'benches',len(benches))
