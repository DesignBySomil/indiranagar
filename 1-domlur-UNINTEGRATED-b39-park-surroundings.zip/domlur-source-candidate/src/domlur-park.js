import * as THREE from 'three';
import {mergeGeometries} from 'three/examples/jsm/utils/BufferGeometryUtils.js';
export function renderDomlurPark(data,scene){const group=new THREE.Group();group.name='Domlur SAARC Park source boundary / creative game fixtures';const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(data.paths,3));g.computeVertexNormals();const paths=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color:0xb3a48c,roughness:.95,side:THREE.DoubleSide}));paths.receiveShadow=true;group.add(paths);const metal=[],wood=[];
 const box=(arr,w,h,d,x,y,z,yaw=0)=>{const g=new THREE.BoxGeometry(w,h,d);g.rotateY(yaw);g.translate(x,y,z);arr.push(g);};
 for(const[a,b,c,d]of data.fence){const L=Math.hypot(c-a,d-b),yaw=Math.atan2(c-a,d-b);box(metal,.07,.85,.07,a,.425,b);for(const y of[.25,.72])box(metal,.045,.045,L,(a+c)/2,y,(b+d)/2,yaw);}
 for(const[x,z,yaw]of data.benches){box(wood,1.6,.10,.55,x,.48,z,yaw);box(wood,1.6,.45,.07,x,.78,z-.26,yaw);for(const dx of[-.6,.6])box(metal,.07,.48,.4,x+dx,.24,z,yaw);}
 for(const[gs,color]of[[metal,0x404d44],[wood,0x7d6249]])if(gs.length){const m=new THREE.Mesh(mergeGeometries(gs),new THREE.MeshStandardMaterial({color,roughness:.9}));m.castShadow=m.receiveShadow=true;group.add(m);gs.forEach(g=>g.dispose());}scene.add(group);return group;}
