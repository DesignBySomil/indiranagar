import {candidateFacadeMaterial} from './domlur-facade-material.js';
import * as THREE from 'three';
import {mergeGeometries} from 'three/examples/jsm/utils/BufferGeometryUtils.js';
// OSM footprints and roads; facade treatment and heights are creative game choices.
// All facade detail stays on the existing collision envelope.
export function renderDomlurScenery(data,roads,land,vegetation,curbs,scene){
 const group=new THREE.Group();group.name='Domlur candidate source footprints / game-only facades';
 for(const [i,l]of land.layers.entries()){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(l.positions,3));g.computeVertexNormals();const m=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color:l.color,roughness:.98,side:THREE.DoubleSide}));m.position.y=.018+i*.0001;m.receiveShadow=true;group.add(m);}
 const trunk=new THREE.InstancedMesh(new THREE.CylinderGeometry(.18,.28,1,9),new THREE.MeshStandardMaterial({color:0x655647,roughness:.96}),vegetation.trees.length),leaves=new THREE.InstancedMesh(new THREE.SphereGeometry(1,12,9),new THREE.MeshStandardMaterial({color:0x4b6143,roughness:.96}),vegetation.trees.length),matrix=new THREE.Matrix4(),quat=new THREE.Quaternion();
 vegetation.trees.forEach(([x,z,h],i)=>{matrix.compose(new THREE.Vector3(x,h*.28,z),quat,new THREE.Vector3(1,h*.56,1));trunk.setMatrixAt(i,matrix);matrix.compose(new THREE.Vector3(x,h*.72,z),quat,new THREE.Vector3(h*.34,h*.30,h*.34));leaves.setMatrixAt(i,matrix);});trunk.castShadow=leaves.castShadow=true;trunk.receiveShadow=leaves.receiveShadow=true;group.add(trunk,leaves);
 const palette=[0xd9d0bd,0xcfc4ae,0xb5b2a9,0xd8cdb9,0xcfc0b0,0xbdb8a8,0xc8a58a,0xa9a8a0],geos=[];
 for(const b of data.buildings){const shape=new THREE.Shape(b.points.map(p=>new THREE.Vector2(p[0],-p[1]))),g=new THREE.ExtrudeGeometry(shape,{depth:b.height,bevelEnabled:false});g.rotateX(-Math.PI/2);g.deleteAttribute('uv');const color=new THREE.Color(palette[Number(b.id)%palette.length]),cs=[];for(let i=0;i<g.attributes.position.count;i++){const shade=g.attributes.normal.getY(i)>.5?.70:.94;cs.push(color.r*shade,color.g*shade,color.b*shade);}g.setAttribute('color',new THREE.Float32BufferAttribute(cs,3));geos.push(g);}
 const buildings=new THREE.Mesh(mergeGeometries(geos),candidateFacadeMaterial());buildings.castShadow=buildings.receiveShadow=true;group.add(buildings);geos.forEach(g=>g.dispose());
 const cg=new THREE.BufferGeometry();cg.setAttribute('position',new THREE.Float32BufferAttribute(curbs.curbs,3));cg.computeVertexNormals();const cm=new THREE.Mesh(cg,new THREE.MeshStandardMaterial({color:0xbbb6a6,roughness:.95,side:THREE.DoubleSide}));cm.receiveShadow=true;group.add(cm);
 for(const [key,color,y] of [['shoulders',0x9a9285,.035],['asphalt',0x55595b,.055]]){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(roads[key],3));g.computeVertexNormals();const m=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color,roughness:.96,side:THREE.DoubleSide}));m.position.y=y;m.receiveShadow=true;group.add(m);}
 scene.add(group);return group;
}
