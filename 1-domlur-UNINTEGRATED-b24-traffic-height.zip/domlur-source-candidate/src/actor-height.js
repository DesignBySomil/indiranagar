import * as THREE from 'three';
const local=new THREE.Matrix4(),world=new THREE.Matrix4(),box=new THREE.Box3();
// Bounds come from the SAME current geometry and instance transform as rendering.
export function instanceHeightOverlap(meshes,index,min,max){
 let lo=Infinity,hi=-Infinity;
 for(const mesh of meshes){if(!mesh?.geometry)continue;if(!mesh.geometry.boundingBox)mesh.geometry.computeBoundingBox();mesh.getMatrixAt(index,local);mesh.updateWorldMatrix(true,false);world.multiplyMatrices(mesh.matrixWorld,local);box.copy(mesh.geometry.boundingBox).applyMatrix4(world);lo=Math.min(lo,box.min.y);hi=Math.max(hi,box.max.y);}
 return Number.isFinite(lo)&&Number.isFinite(hi)?min<=hi&&max>=lo:true;
}
