import * as THREE from 'three';
// QA-only south wall aperture. Existing other map limits remain unchanged.
export function openDomlurEntry(edge,data){
 if(!edge||edge.domlurPortal)return;
 const wall=edge.group.children[1],z=wall.position.z,centers=[];
 for(const points of[data.groundPortal.points,data.groundApproach.points])for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i];if((a[1]-z)*(b[1]-z)<=0&&a[1]!==b[1])centers.push(a[0]+(b[0]-a[0])*(z-a[1])/(b[1]-a[1]));}
 if(centers.length!==2)throw Error('two actual road crossings required');
 const lo=Math.min(...centers)-4,hi=Math.max(...centers)+4,left=wall.position.x-wall.geometry.parameters.width/2,right=wall.position.x+wall.geometry.parameters.width/2;
 wall.visible=false;
 for(const[a,b]of[[left,lo],[hi,right]]){const m=new THREE.Mesh(new THREE.BoxGeometry(b-a,wall.geometry.parameters.height,wall.geometry.parameters.depth),wall.material);m.position.copy(wall.position);m.position.x=(a+b)/2;edge.group.add(m);}
 edge.domlurPortal={lo,hi,z,centers};return edge.domlurPortal;
}
