import * as THREE from 'three';
// Diagnostic renderer for 3 routes, game-only dimensions; not complete flyover scenery.
export function renderDomlurCandidate(data,scene){const group=new THREE.Group();group.name='UNINTEGRATED Domlur routes';const asphalt=new THREE.MeshStandardMaterial({color:0x44494c,roughness:.92,side:THREE.DoubleSide}),edge=new THREE.LineBasicMaterial({color:0xe4e2d5});
for(const r of Object.values(data.routes)){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(r.triangles.flat(2),3));g.computeVertexNormals();const mesh=new THREE.Mesh(g,asphalt);mesh.receiveShadow=true;group.add(mesh);
 // Height sample matches the triangle vertex heights, not an independent flat deck assumption.
 const verts=r.triangles.flat();const near=(x,z)=>{let d=Infinity,y=0;for(const p of verts){const q=(p[0]-x)**2+(p[2]-z)**2;if(q<d){d=q;y=p[1]}}return y};
 const pts=r.boundary.map(([x,z])=>new THREE.Vector3(x,near(x,z)+.04,z));const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),edge);group.add(line);
}
scene.add(group);return group;}
