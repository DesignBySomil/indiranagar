# SOURCE-ONLY opt-in harness, not an implemented flyover
Base: original boundary candidate 3bcd1e7f53fbcfbaf18af44d26636ff5a2598fad.
No production, accepted tree or normal-game map changes.

New QA-only load/attach entry points exercise the support adapter in a separate early-return branch. They deliberately do not integrate rendering, camera, traffic, impacts, recovery or scenery. Do not deploy this as a finished feature.

Default ground path regression: 16697 simulation steps, 31 loop nodes, 1403.662591 m travel, 0 recoveries. Full trace JSON exactly equals the accepted baseline (including all positions, velocities and metrics). This covers one loop with movers disabled, not every ground behavior.

Adapter standalone support: north4781,airport5308,south4797 samples using the existing game's seven body-probe offsets. These are not input-driven game drives. No grade pitch, dynamic collisions, branch switches or attached-road renderer yet. Game heights and width are provisional, not surveyed.

## Batch 6: key-driven harness runs
Three routes driven with dispatched W/A/D inputs in the opt-in candidate branch at about 4 m/s. Reached every route node within 1.5 m threshold: northbound 476.741 m / 7062 steps, airport-to-north 529.017 m / 7835 steps, southbound 478.366 m / 7086 steps. No support refusal (zero-speed block) in these runs. Max height change per tick <=0.01065 m. Two seconds S from final forward speed ends v=-6 and net backward signed displacement 6.695/6.817/6.719 m.
These runs use simplified opt-in dynamics and omit the main collision/recovery/camera path. They are evidence for the adapter harness, not accepted game driving or visual flyover acceptance. No physical device or browser-rendered flyover pixels validated.

## Batch 7: visual diagnostic, blocked
Added explicit-load-only three-route diagnostic renderer and simple chase pose. At ~210 m, south full post image shows auto/road in empty brown environment. Airport-to-north full post image is black. Fresh isolated Airport run: raw renderer is visible, full post remains black, so this narrows the failure to the post-render path in this candidate but does not identify its cause. Raw image also exposes an unrelated huge clipped object in sky and distant current-map boundary. No visual acceptance. No production changes. render-results.json was overwritten by the most recent diagnostic run. No complete flyover scene, rails/piers/collision/main camera integration.

## Batch 8: post-path isolation, still blocked
Same Airport pose: no AO remains black; Render+Output only visible; no bloom only visible; no grade only black; no grain only black. Therefore bloom or its inputs are implicated, root cause not known. No quality cut applied to game. Added lighting/shadow updates in opt-in harness to keep sky centered on moving auto; full post remains black. Script variants are diagnostics, not fixes. bloom-findings.json records the pass-isolation result.

## Batch 9: bounded foliage-normal guard
At exact failing Airport pose, float readback found 12 NaN channels before bloom (3 with AO off), spreading through bloom mips. Ray located flat-shaded instanced tree foliage. Candidate-only trees.js shader guards normalization of derivative cross product when squared length <=1e-20. Same-pose all-effects render: input and every bloom target now zero NaNs; full-post image visible. Does not prove map-wide/device safety. No effect disabled. Sky clipping also gone after the batch-8 missing lighting/sky-follow update. Extension remains empty diagnostic, not accepted gameplay.
