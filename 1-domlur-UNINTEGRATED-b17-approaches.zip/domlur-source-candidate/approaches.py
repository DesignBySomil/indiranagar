# Actual directed source paths, no interpolation between disconnected roads.
import json,math
from shapely.geometry import LineString,box
from shapely.ops import triangulate
base='public/data/';m=json.load(open('/tmp/deep-research/domlur/merged-map.json'));ws={w['id']:w for w in m['roads']};d=json.load(open(base+'domlur-candidate.json'));g=json.load(open(base+'domlur-joined.json'))
def chain(ids):
 ns=[];ps=[]
 for id in ids:
  w=ws[id]
  if ns:assert ns[-1]==w['nodes'][0],id
  ns.extend(w['nodes'][bool(ns):]);ps.extend(w['p'][bool(ps):])
 for n,p in zip(ns,ps):
  if n not in d['nodes']:d['nodes'][n]={'p':p,'y':0,'branch':False,'distanceToGround':0}
 return ns,ps
north=['1109947893','1109947894','1149153347','464465173','1227746103'];ns,ps=chain(north);d['groundPortal'].update(nodes=ns,points=ps,wayIds=north,scope='Actual directed north continuation to existing map overlap; not main-game automatic attach')
south=['543470389','1109947891','1109947892','1314297631'];ss,sp=chain(south);assert ss[-1]==d['routes']['southbound']['nodes'][0];d['groundApproach']={'name':'south_ground','nodes':ss,'points':sp,'wayIds':south,'route':'southbound','scope':'Actual directed south approach, not automatic main-game attach'}
for name,ps in [('north_ground',ps),('south_ground',sp)]:
 # Existing terrain surface is at Y0. Tiny draw offset avoids z fighting; support stays Y0.
 poly=LineString(ps).buffer(3.3,cap_style=1,join_style=1,quad_segs=8).intersection(box(-10000,747,10000,10000));pending=[list(t.exterior.coords)[:3] for t in triangulate(poly) if poly.covers(t)];fine=[]
 while pending:
  t=pending.pop();i=max(range(3),key=lambda i:math.dist(t[i],t[(i+1)%3]))
  if math.dist(t[i],t[(i+1)%3])>2:
   a,b,c=t[i],t[(i+1)%3],t[(i+2)%3];mid=[(a[j]+b[j])/2 for j in range(2)];pending.extend([[a,mid,c],[mid,b,c]])
  else:fine.append([[x,.015,z]for x,z in t])
 g['routes'][name]={'points':[[*p,0]for p in ps],'boundary':list(poly.exterior.coords),'triangles':fine,'railSegments':[],'ground':True,'visualOffset':.015}
json.dump(d,open(base+'domlur-candidate.json','w'));json.dump(g,open(base+'domlur-joined.json','w'));print({n:len(g['routes'][n]['triangles'])for n in ['north_ground','south_ground']})
