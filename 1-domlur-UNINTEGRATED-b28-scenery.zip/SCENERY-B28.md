# Unintegrated Domlur candidate, batch 28

Added source-ground-road scenery from the retained OSM road projection, game-width shoulders, and merged warm facade/window geometry on the exact existing building envelopes. No source footprint or gameplay height change. Building-game metadata now correctly describes its candidate use, replacing the stale read-only audit label.

Inspected chase, driver and passenger pixels at about 200m elevated curve, 500m ramp descent, 650m ground corridor, and 1200m accepted-city overlap. Road is visible in all sampled views. Elevated surroundings still look sparse and the new corridor is visibly simpler than accepted-city scenery. These are samples, not full route-wide camera acceptance. No physical device acceptance.

Re-ran airport-to-north main physics with movers on after this scenery change: 48/48 nodes, 1375.673976m, 8265 ticks, zero blocks, max vertical step .019097m. This is the same trace as before scenery. Ground-road scenery outside the candidate support does not grant driving support there.

No accepted source/map changes or deployment. Pending: scenery continuity, full camera clearance, adversarial mixed-height/parked targeting, device checks. Local batch, not yet remote-persisted.
