import * as THREE from 'three';
import {mergeGeometries} from 'three/examples/jsm/utils/BufferGeometryUtils.js';
// OSM footprints and roads; facade treatment and heights are creative game choices.
// All facade detail stays on the existing collision envelope.
export function renderDomlurScenery(data,roads,scene){
 const group=new THREE.Group();group.name='Domlur candidate source footprints / game-only facades';
 const palette=[0xd9d0bd,0xcfc4ae,0xb5b2a9,0xd8cdb9,0xcfc0b0,0xbdb8a8,0xc8a58a,0xa9a8a0],buckets=palette.map(()=>[]),windows=[];
 for(const b of data.buildings){
  const pts=b.points,h=b.height,seed=Number(b.id)%997;
  const shape=new THREE.Shape(pts.map(p=>new THREE.Vector2(p[0],-p[1]))),g=new THREE.ExtrudeGeometry(shape,{depth:h,bevelEnabled:false});g.rotateX(-Math.PI/2);g.deleteAttribute('uv');buckets[seed%palette.length].push(g);
  // Flush facade windows, no added overhang or invisible collision volume.
  for(let i=1;i<pts.length;i++){const a=pts[i-1],c=pts[i],dx=c[0]-a[0],dz=c[1]-a[1],L=Math.hypot(dx,dz);if(L<3)continue;
   for(let y=2.1;y<h-.7;y+=3.3)for(let s=1.8;s<L-1.2;s+=3.6){if((Math.floor(s)+seed)%5===0)continue;const cx=a[0]+dx*s/L,cz=a[1]+dz*s/L,wx=dx/L*.52,wz=dz/L*.52;
    windows.push(cx-wx,y-.65,cz-wz,cx+wx,y-.65,cz+wz,cx-wx,y+.65,cz-wz,cx-wx,y+.65,cz-wz,cx+wx,y-.65,cz+wz,cx+wx,y+.65,cz+wz);
   }
  }
 }
 buckets.forEach((gs,i)=>{if(!gs.length)return;const m=new THREE.Mesh(mergeGeometries(gs),new THREE.MeshStandardMaterial({color:palette[i],roughness:.94}));m.castShadow=true;m.receiveShadow=true;group.add(m);gs.forEach(g=>g.dispose());});
 const wg=new THREE.BufferGeometry();wg.setAttribute('position',new THREE.Float32BufferAttribute(windows,3));wg.computeVertexNormals();const wm=new THREE.Mesh(wg,new THREE.MeshStandardMaterial({color:0x37474b,roughness:.7,side:THREE.DoubleSide,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1}));group.add(wm);
 for(const [key,color,y] of [['shoulders',0x9a9285,.004],['asphalt',0x55595b,.009]]){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(roads[key],3));g.computeVertexNormals();const m=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color,roughness:.96,side:THREE.DoubleSide}));m.position.y=y;m.receiveShadow=true;group.add(m);}
 scene.add(group);return group;
}
