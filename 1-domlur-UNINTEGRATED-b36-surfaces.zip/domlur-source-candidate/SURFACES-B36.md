# Unintegrated batch36: candidate surfaces and facade variation

Candidate asphalt/concrete now use deterministic candidate-local texture art and world-coordinate UVs. No shared random generator consumption, footprint/support/rail geometry unchanged. Asphalt stays dark after daylight inspection corrected an initially over-light tone. Facade bay spacing/window widths and band/shutter layout vary by source ID while remaining on existing planes.

Inspected noon actual-drive samples at200m elevated curve,650m corridor,1000m accepted-city transition. Road and concrete now have surface detail; transition coverage remains filled. Elevated surroundings and facade quality still basic and not claimed equal to accepted-city quality. No physical-device or overall acceptance. No accepted source/deployment change. Local patch, not remotely preserved yet.
