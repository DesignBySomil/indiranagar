import {candidateSurface} from './domlur-materials.js';
import * as THREE from 'three';
// Candidate-only three-route structure. Dimensions are game choices, not survey.
export function renderDomlurCandidate(data,scene){
 const group=new THREE.Group();group.name='UNINTEGRATED Domlur routes';
 const asphalt=candidateSurface('asphalt'),concrete=candidateSurface('concrete');
 const mesh=(v,mat)=>{const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(v,3));const uv=[];for(let i=0;i<v.length;i+=3){if(mat===asphalt)uv.push(v[i]/7,v[i+2]/7);else uv.push((v[i]+v[i+2])/4,v[i+1]/2);}g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.computeVertexNormals();const m=new THREE.Mesh(g,mat);m.castShadow=true;m.receiveShadow=true;group.add(m);};
 for(const r of Object.values(data.routes)){
  const height=(x,z)=>{let best=Infinity,y=0;for(let i=1;i<r.points.length;i++){const a=r.points[i-1],b=r.points[i],dx=b[0]-a[0],dz=b[1]-a[1],l2=dx*dx+dz*dz,t=Math.max(0,Math.min(1,((x-a[0])*dx+(z-a[1])*dz)/l2)),d=(x-a[0]-t*dx)**2+(z-a[1]-t*dz)**2;if(d<best){best=d;y=a[2]+(b[2]-a[2])*t}}return y;};
  mesh(r.triangles.flat(2),asphalt);
  if(r.ground)continue; // Single shared ground mesh, not a second flyover slab.
  const underside=[];for(const tri of r.triangles){for(const p of [tri[0],tri[2],tri[1]])underside.push(p[0],p[1]-.4,p[2]);}mesh(underside,concrete);
  const walls=[],rails=[];
  for(let i=1;i<r.boundary.length;i++){
   const a=r.boundary[i-1],b=r.boundary[i],ya=height(...a),yb=height(...b);
   const quad=(arr,lo,hi)=>{arr.push(a[0],ya+lo,a[1],b[0],yb+lo,b[1],a[0],ya+hi,a[1],a[0],ya+hi,a[1],b[0],yb+lo,b[1],b[0],yb+hi,b[1]);};
   if(!r.railSegments)quad(walls,-.4,0);
   // Keep 4m endpoint portals open. Shared route merges still require boundary union, not accepted yet.
   const ends=[r.points[0],r.points.at(-1)];const mid=[(a[0]+b[0])/2,(a[1]+b[1])/2];
   if(!r.railSegments&&!ends.some(p=>Math.hypot(mid[0]-p[0],mid[1]-p[1])<4))quad(rails,0,.65);
  }
  if(r.railSegments)for(const [a,b] of r.railSegments){walls.push(a[0],a[1]-.4,a[2],b[0],b[1]-.4,b[2],a[0],a[1],a[2],a[0],a[1],a[2],b[0],b[1]-.4,b[2],b[0],b[1],b[2]);rails.push(a[0],a[1],a[2],b[0],b[1],b[2],a[0],a[1]+.65,a[2],a[0],a[1]+.65,a[2],b[0],b[1],b[2],b[0],b[1]+.65,b[2]);}
  mesh(walls,concrete);mesh(rails,concrete);
 }
 scene.add(group);return group;
}
