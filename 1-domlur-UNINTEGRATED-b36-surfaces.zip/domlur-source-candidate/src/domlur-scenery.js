import * as THREE from 'three';
import {mergeGeometries} from 'three/examples/jsm/utils/BufferGeometryUtils.js';
// OSM footprints and roads; facade treatment and heights are creative game choices.
// All facade detail stays on the existing collision envelope.
export function renderDomlurScenery(data,roads,land,vegetation,scene){
 const group=new THREE.Group();group.name='Domlur candidate source footprints / game-only facades';
 for(const [i,l]of land.layers.entries()){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(l.positions,3));g.computeVertexNormals();const m=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color:l.color,roughness:.98,side:THREE.DoubleSide}));m.position.y=.001+i*.00003;m.receiveShadow=true;group.add(m);}
 const trunk=new THREE.InstancedMesh(new THREE.CylinderGeometry(.18,.28,1,9),new THREE.MeshStandardMaterial({color:0x655647,roughness:.96}),vegetation.trees.length),leaves=new THREE.InstancedMesh(new THREE.SphereGeometry(1,12,9),new THREE.MeshStandardMaterial({color:0x4b6143,roughness:.96}),vegetation.trees.length),matrix=new THREE.Matrix4(),quat=new THREE.Quaternion();
 vegetation.trees.forEach(([x,z,h],i)=>{matrix.compose(new THREE.Vector3(x,h*.28,z),quat,new THREE.Vector3(1,h*.56,1));trunk.setMatrixAt(i,matrix);matrix.compose(new THREE.Vector3(x,h*.72,z),quat,new THREE.Vector3(h*.34,h*.30,h*.34));leaves.setMatrixAt(i,matrix);});trunk.castShadow=leaves.castShadow=true;trunk.receiveShadow=leaves.receiveShadow=true;group.add(trunk,leaves);
 const palette=[0xd9d0bd,0xcfc4ae,0xb5b2a9,0xd8cdb9,0xcfc0b0,0xbdb8a8,0xc8a58a,0xa9a8a0],buckets=palette.map(()=>[]),details={glass:[],frame:[],band:[],shutter:[],dark:[]};
 for(const b of data.buildings){
  const pts=b.points,h=b.height,seed=Number(b.id)%997;
  const shape=new THREE.Shape(pts.map(p=>new THREE.Vector2(p[0],-p[1]))),g=new THREE.ExtrudeGeometry(shape,{depth:h,bevelEnabled:false});g.rotateX(-Math.PI/2);g.deleteAttribute('uv');buckets[seed%palette.length].push(g);
  // Flush facade layers stay on the source footprint envelope. Detail is game art.
  for(let i=1;i<pts.length;i++){const a=pts[i-1],c=pts[i],dx=c[0]-a[0],dz=c[1]-a[1],L=Math.hypot(dx,dz);if(L<3)continue;
   const rect=(key,lo,hi,y0,y1)=>{const p=(s,y)=>[a[0]+dx*s/L,y,a[1]+dz*s/L],v=[p(lo,y0),p(hi,y0),p(lo,y1),p(lo,y1),p(hi,y0),p(hi,y1)];details[key].push(...v.flat());};
   const bay=3.2+(seed%4)*.4,win=.52+(seed%3)*.10;
   for(let y=3.3;y<h-.2;y+=3.3){if(seed%3!==0)rect('band',0,L,y-.12,y+.12);}
   for(let y=4.8;y<h-.6;y+=3.3)for(let d=1.8;d<L-1.2;d+=bay){rect('frame',d-win-.13,d+win+.13,y-.9,y+.9);rect('glass',d-win,d+win,y-.76,y+.76);rect('band',d-.025,d+.025,y-.76,y+.76);rect('band',d-win,d+win,y-.03,y+.03);}
   if(h>5&&seed%3!==0)for(let d=1.9;d<L-1.4;d+=4.2){rect('dark',d-1.35,d+1.35,.15,2.85);rect('shutter',d-1.18,d+1.18,.18,2.50);for(let y=.5;y<2.4;y+=.28)rect('band',d-1.18,d+1.18,y,y+.018);rect('frame',d-1.35,d+1.35,2.55,2.85);}
   if(seed%3===0)for(let d=1;d<L;d+=bay)rect('band',d,d+.17,.1,h-.2);
   rect('band',0,L,h-.22,h-.04);
  }
 }
 buckets.forEach((gs,i)=>{if(!gs.length)return;const m=new THREE.Mesh(mergeGeometries(gs),new THREE.MeshStandardMaterial({color:palette[i],roughness:.94}));m.castShadow=true;m.receiveShadow=true;group.add(m);gs.forEach(g=>g.dispose());});
 const detailColors={glass:0x435660,frame:0x96998f,band:0x686b65,shutter:0x797b70,dark:0x303735};
 for(const[key,pos]of Object.entries(details)){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.computeVertexNormals();const order=['dark','shutter','frame','glass','band'].indexOf(key);const mesh=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color:detailColors[key],roughness:.85,side:THREE.DoubleSide,polygonOffset:true,polygonOffsetFactor:-2-order,polygonOffsetUnits:-2-order}));mesh.receiveShadow=true;group.add(mesh);}
 for(const [key,color,y] of [['shoulders',0x9a9285,.004],['asphalt',0x55595b,.009]]){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(roads[key],3));g.computeVertexNormals();const m=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color,roughness:.96,side:THREE.DoubleSide}));m.position.y=y;m.receiveShadow=true;group.add(m);}
 scene.add(group);return group;
}
