import * as THREE from 'three';
// Seeded candidate-only surface art. Never consumes the accepted world's RNG.
export function candidateSurface(kind){
 const c=document.createElement('canvas');c.width=c.height=256;const ctx=c.getContext('2d'),img=ctx.createImageData(256,256);let seed=kind==='asphalt'?3627:9173;const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 for(let y=0;y<256;y++)for(let x=0;x<256;x++){const i=(y*256+x)*4,n=(rnd()-.5)*(kind==='asphalt'?21:12),v=(kind==='asphalt'?111:175)+n;img.data[i]=v;img.data[i+1]=v+(kind==='asphalt'?2:0);img.data[i+2]=v+(kind==='asphalt'?4:-7);img.data[i+3]=255;}
 ctx.putImageData(img,0,0);
 if(kind==='asphalt'){ctx.strokeStyle='rgba(25,27,29,.36)';ctx.lineWidth=1.4;for(let k=0;k<4;k++){let x=rnd()*256,y=rnd()*256;ctx.beginPath();ctx.moveTo(x,y);for(let j=0;j<5;j++){x+=(rnd()-.5)*35;y+=rnd()*24;ctx.lineTo(x,y);}ctx.stroke();}}
 else {for(let k=0;k<24;k++){const x=rnd()*256;ctx.fillStyle='rgba(50,50,42,.045)';ctx.fillRect(x,0,2+rnd()*9,256);}}
 const map=new THREE.CanvasTexture(c);map.wrapS=map.wrapT=THREE.RepeatWrapping;map.colorSpace=THREE.SRGBColorSpace;map.anisotropy=4;
 return new THREE.MeshStandardMaterial({map,color:kind==='asphalt'?0x92979a:0xffffff,roughness:.94,side:THREE.DoubleSide});
}
