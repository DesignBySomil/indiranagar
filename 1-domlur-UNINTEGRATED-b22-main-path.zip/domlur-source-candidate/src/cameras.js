// src/cameras.js
import * as THREE from 'three';
import { makeSign } from './materials.js';

export const CAMERA_CSS = `
#btn-cam {
  position: fixed;
  right: 18px;
  bottom: 22px;
  z-index: 42;
  cursor: pointer;
  background: rgba(12, 16, 28, 0.88);
  color: #f8fafc;
  border: 2px solid #facc15;
  border-radius: 999px;
  padding: 9px 16px 9px 13px;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  line-height: 1;
  font-family: "Bricolage Grotesque", system-ui, sans-serif;
  font-size: 13px;
  font-weight: 800;
  letter-spacing: 0.02em;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(8px);
  transition: transform 0.15s ease, background 0.15s ease;
}
#btn-cam:hover {
  transform: translateY(-2px);
  background: rgba(24, 32, 54, 0.95);
}
#btn-cam span {
  color: #facc15;
}
#btn-cam svg { width: 18px; height: 18px; flex: none; color: #facc15; }
#btn-cam .kbd { opacity: 0.6; font-weight: 600; font-style: normal; }
#btn-cam b { font-weight: 800; }
@media (max-width: 520px) {
  #btn-cam { right: 12px; bottom: 14px; padding: 8px 12px 8px 10px; font-size: 12px; }
  #btn-cam .kbd { display: none; }
}
`;

const CAM_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="6" width="14" height="12" rx="2.5"/><path d="M16 10.5l5.5-3v9l-5.5-3z"/></svg>';
const MODES = ['chase', 'driver', 'passenger'];
const MODE_LABELS = {
  chase: '3rd-Person Chase',
  driver: 'Driver Cockpit',
  passenger: 'Back Seat'
};

export function createCameraRig({ THREE: T = THREE, camera, auto, carGroup, scene }) {
  if (typeof document !== 'undefined' && !document.getElementById('camera-rig-css')) {
    const st = document.createElement('style');
    st.id = 'camera-rig-css';
    st.textContent = CAMERA_CSS;
    document.head.appendChild(st);
  }

  // Create bottom-right camera view button (#btn-cam)
  let camBtn = typeof document !== 'undefined' ? document.getElementById('btn-cam') : null;
  if (typeof document !== 'undefined' && !camBtn) {
    camBtn = document.createElement('button');
    camBtn.id = 'btn-cam';
    document.body.appendChild(camBtn);
  }

  const speedPanel = document.createElement('section');
  speedPanel.id = 'drive-panel';
  speedPanel.innerHTML = '<div class="drive-body"><div class="drive-title">AUTO RICKSHAW</div><div class="drive-reading"><span id="drive-speed">0</span><span class="drive-unit">MPH</span></div><div class="drive-track"><div id="drive-fill"></div></div></div><div class="drive-views"><button id="drive-prev" aria-label="Previous camera">‹</button><div id="drive-current"></div><button id="drive-next" aria-label="Next camera">›</button></div>';
  document.body.appendChild(speedPanel);
  speedPanel.querySelector('#drive-current').appendChild(camBtn);
  const panelStyle=document.createElement('style');
  panelStyle.textContent=`
#drive-panel{position:fixed;right:18px;bottom:18px;z-index:42;width:290px;background:rgba(17,23,27,.94);border:1px solid #41484b;border-radius:22px;color:#f4f5f5;font-family:system-ui,sans-serif;box-shadow:0 10px 30px #0008;overflow:hidden;backdrop-filter:blur(10px)}
.drive-body{padding:17px 20px 15px}.drive-title{color:#939a9c;letter-spacing:2px;font-size:12px;font-weight:700}.drive-reading{display:flex;align-items:baseline;gap:9px;margin:6px 0 13px}#drive-speed{font-size:46px;line-height:1.1;font-weight:500;font-variant-numeric:tabular-nums}.drive-unit{font-size:15px;font-weight:700;color:#90989b;letter-spacing:1px}.drive-track{height:4px;background:#3d4549;border-radius:4px;overflow:hidden}#drive-fill{height:100%;width:0;background:#dde6e9;transition:width .15s}.drive-views{display:flex;align-items:center;border-top:1px solid #42494c;padding:12px 9px;gap:3px}.drive-views>button{background:none;color:#a6afb2;border:0;font-size:28px;cursor:pointer;width:27px}#drive-current{flex:1;min-width:0}#drive-panel #btn-cam{position:static;display:flex;width:100%;justify-content:center;border:0;border-radius:0;background:none;padding:0;box-shadow:none;font-size:13px;font-weight:600;letter-spacing:0;gap:6px;backdrop-filter:none;transform:none}#drive-panel #btn-cam span{white-space:nowrap}#drive-panel #btn-cam span,#drive-panel #btn-cam svg{color:#edf0f1}#drive-panel #btn-cam .kbd{background:#343c40;border:1px solid #495053;border-radius:5px;padding:3px;font-size:11px}#drive-panel #btn-cam b{display:none}
@media(max-width:600px){#drive-panel{width:220px;right:10px;bottom:12px;border-radius:17px}.drive-body{padding:12px 15px 11px}#drive-speed{font-size:36px}.drive-title{font-size:10px}.drive-reading{margin:4px 0 9px}.drive-views{padding:9px 5px}#drive-panel #btn-cam{font-size:10px}#drive-panel #btn-cam svg{width:15px}#drive-panel #btn-cam .kbd{display:inline}.drive-views>button{font-size:22px;width:22px}}
@media(max-width:360px){#drive-panel{width:180px}.drive-body{padding:10px 12px}.drive-title{font-size:9px;letter-spacing:1px}.drive-views{gap:0;padding:9px 3px}.drive-views>button{width:17px;font-size:19px}#drive-panel #btn-cam{font-size:9px;gap:4px}#drive-panel #btn-cam svg{width:12px}#drive-panel #btn-cam .kbd{display:none}}
@media(max-height:440px){#drive-panel{width:240px;bottom:10px}.drive-body{padding:9px 13px}#drive-speed{font-size:31px}.drive-reading{margin:3px 0 7px}.drive-views{padding:7px 5px}}
`;
  document.head.appendChild(panelStyle);

  // Build detailed First-Person Cockpit + Back-Seat Driver Avatar attached to carGroup
  const cockpitGroup = new T.Group();
  const driverAvatar = new T.Group();

  // Build cockpit details (windshield surround, digital red LED meter, dashboard sticker, steerable handlebar)
  const blkMat = new T.MeshStandardMaterial({ color: 0x15181c, roughness: 0.7 });
  const chromeMat = new T.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.2, metalness: 0.85 });
  const khakiMat = new T.MeshStandardMaterial({ color: 0xc2a36b, roughness: 0.75 });
  const skinMat = new T.MeshStandardMaterial({ color: 0xd4946a, roughness: 0.65 });

  // ---- Driver POV: handlebar with grips, brake levers, mirrors, speedo pod ----
  const rubberMat = new T.MeshStandardMaterial({ color: 0x0c0d0f, roughness: 0.9 });
  const steelMat = new T.MeshStandardMaterial({ color: 0xaab2bd, roughness: 0.3, metalness: 0.85 });
  const redMat = new T.MeshStandardMaterial({ color: 0xc81e1e, roughness: 0.5 });
  const cockpitBar = new T.Group();
  cockpitBar.position.set(0, 1.02, 0.70);
  const crossTube = new T.Mesh(new T.CylinderGeometry(0.014, 0.014, 0.64, 10), steelMat);
  crossTube.rotation.z = Math.PI / 2;
  cockpitBar.add(crossTube);
  for (const sg of [-1, 1]) {
    const grip = new T.Mesh(new T.CylinderGeometry(0.021, 0.021, 0.12, 12), rubberMat);
    grip.rotation.z = Math.PI / 2; grip.position.set(sg * 0.30, 0, 0);
    const lever = new T.Mesh(new T.BoxGeometry(0.012, 0.012, 0.11), steelMat);
    lever.position.set(sg * 0.22, -0.012, 0.05); lever.rotation.y = sg * 0.18;
    const stalk = new T.Mesh(new T.CylinderGeometry(0.007, 0.007, 0.26, 6), steelMat);
    stalk.position.set(sg * 0.34, 0.13, 0.02); stalk.rotation.z = -sg * 0.25;
    const mirror = new T.Mesh(new T.CylinderGeometry(0.06, 0.06, 0.012, 20), steelMat);
    mirror.rotation.x = Math.PI / 2; mirror.position.set(sg * 0.385, 0.27, 0.02); mirror.rotation.y = -sg * 0.35;
    const glass = new T.Mesh(new T.CircleGeometry(0.052, 20), new T.MeshStandardMaterial({ color: 0x9fb8cc, roughness: 0.1, metalness: 0.9 }));
    glass.position.set(0, 0, -0.0075); glass.rotation.y = Math.PI; mirror.add(glass);
    cockpitBar.add(grip, lever);
  }
  const pod = new T.Mesh(new T.CylinderGeometry(0.065, 0.075, 0.07, 24), rubberMat);
  pod.position.set(0, 0.06, 0.02); pod.rotation.x = -0.9;
  const speedoCanvas = document.createElement('canvas'); speedoCanvas.width = speedoCanvas.height = 128;
  const speedoCtx = speedoCanvas.getContext('2d');
  const speedoTex = new T.CanvasTexture(speedoCanvas); speedoTex.colorSpace = T.SRGBColorSpace;
  let lastSpeedDrawn = -1;
  function drawSpeedo(kmh) {
    const k = Math.round(kmh);
    if (k === lastSpeedDrawn) return; lastSpeedDrawn = k;
    const c = speedoCtx; c.fillStyle = '#05070a'; c.fillRect(0, 0, 128, 128);
    c.strokeStyle = '#e5e7eb'; c.lineWidth = 3;
    for (let i = 0; i <= 8; i++) { const a = Math.PI * (0.75 + 1.5 * i / 8); c.beginPath(); c.moveTo(64 + Math.cos(a) * 46, 64 + Math.sin(a) * 46); c.lineTo(64 + Math.cos(a) * 56, 64 + Math.sin(a) * 56); c.stroke(); }
    const a = Math.PI * (0.75 + 1.5 * Math.min(1, k / 80));
    c.strokeStyle = '#ef4444'; c.lineWidth = 4; c.beginPath(); c.moveTo(64, 64); c.lineTo(64 + Math.cos(a) * 44, 64 + Math.sin(a) * 44); c.stroke();
    c.fillStyle = '#facc15'; c.font = '700 22px monospace'; c.textAlign = 'center'; c.fillText(String(k), 64, 100);
    speedoTex.needsUpdate = true;
  }
  const speedoFace = new T.Mesh(new T.CircleGeometry(0.058, 28), new T.MeshBasicMaterial({ map: speedoTex }));
  speedoFace.position.set(0, 0.036, 0); speedoFace.rotation.x = -Math.PI / 2; pod.add(speedoFace);
  cockpitBar.add(pod);
  cockpitGroup.add(cockpitBar);
  // small Ganesha idol + tricolour tassel on the dash
  const idol = new T.Mesh(new T.SphereGeometry(0.035, 10, 8), new T.MeshStandardMaterial({ color: 0xd97706, roughness: 0.5, metalness: 0.3 }));
  idol.position.set(0.30, 1.03, 0.90); /* idol removed */

  // ---- Driver seen from behind (passenger view): human proportions ----
  const shirtMat = new T.MeshStandardMaterial({ color: 0x5b6b82, roughness: 0.9 });
  const driverAvatar2 = new T.Group();
  const torso = new T.Mesh(new T.CylinderGeometry(0.17, 0.2, 0.5, 14), shirtMat); torso.position.set(0, 1.02, 0.26); torso.scale.z = 0.7;
  const shoulders = new T.Mesh(new T.CapsuleGeometry(0.075, 0.30, 4, 10), shirtMat); shoulders.rotation.z = Math.PI / 2; shoulders.position.set(0, 1.25, 0.26);
  const neck = new T.Mesh(new T.CylinderGeometry(0.042, 0.047, 0.08, 10), skinMat); neck.position.set(0, 1.325, 0.26);
  const head = new T.Mesh(new T.SphereGeometry(0.088, 16, 12), skinMat); head.scale.set(0.92, 1.12, 1.0); head.position.set(0, 1.415, 0.26);
  const hair = new T.Mesh(new T.SphereGeometry(0.091, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.62), blkMat); hair.scale.set(0.95, 1.12, 1.05); hair.position.set(0, 1.435, 0.255);
  const ears = [-1, 1].map(sg => { const e = new T.Mesh(new T.SphereGeometry(0.019, 8, 6), skinMat); e.position.set(sg * 0.083, 1.415, 0.26); return e; });
  driverAvatar2.add(torso, shoulders, neck, head, hair, ...ears);
  for (const sg of [-1, 1]) {
    const up = new T.Mesh(new T.CapsuleGeometry(0.04, 0.2, 4, 8), shirtMat);
    up.position.set(sg * 0.22, 1.12, 0.38); up.rotation.set(1.0, 0, sg * 0.25);
    const fore = new T.Mesh(new T.CapsuleGeometry(0.034, 0.2, 4, 8), skinMat);
    fore.position.set(sg * 0.27, 1.0, 0.56); fore.rotation.set(1.35, 0, sg * 0.12);
    const hand = new T.Mesh(new T.SphereGeometry(0.036, 8, 6), skinMat); hand.position.set(sg * 0.30, 0.94, 0.66);
    driverAvatar2.add(up, fore, hand);
  }
  driverAvatar.add(driverAvatar2);

  // ---- Back-seat rig (matches the reference photo): seat back, grab rails, extinguisher ----
  const seatMat = new T.MeshStandardMaterial({ color: 0x4a3426, roughness: 0.9 });
  const seatBack = new T.Mesh(new T.BoxGeometry(0.70, 0.36, 0.12), seatMat); seatBack.position.set(0, 1.08, 0.02);
  const seatTop = new T.Mesh(new T.BoxGeometry(0.58, 0.04, 0.14), rubberMat); seatTop.position.set(0, 1.19, 0.0);
  driverAvatar.add(seatBack, seatTop);
  for (const yy of [1.17, 1.31]) {
    const bar = new T.Mesh(new T.CylinderGeometry(0.013, 0.013, 1.3, 8), steelMat); bar.rotation.z = Math.PI / 2; bar.position.set(0, yy, -0.08); driverAvatar.add(bar);
  }
  for (const sg of [-1, 1]) for (const yy of [1.12, 1.26]) {
    const rail = new T.Mesh(new T.CylinderGeometry(0.013, 0.013, 1.3, 8), steelMat); rail.rotation.x = Math.PI / 2; rail.position.set(sg * 0.66, yy, 0.2); driverAvatar.add(rail);
  }
  const ext = new T.Mesh(new T.CylinderGeometry(0.065, 0.065, 0.34, 14), redMat); ext.position.set(-0.40, 1.18, -0.12);
  const extTop = new T.Mesh(new T.CylinderGeometry(0.03, 0.05, 0.07, 10), rubberMat); extTop.position.set(-0.40, 1.37, -0.12);
  driverAvatar.add(ext, extTop);

  const cabinLight = new T.PointLight(0xffe0a8, 2.6, 6, 1.4); cabinLight.position.set(0, 1.72, -0.2); driverAvatar.add(cabinLight);
  for (const sg of [-1, 1]) {
    const st = new T.Mesh(new T.CylinderGeometry(0.012, 0.012, 0.3, 6), steelMat); st.rotation.z = sg * 1.2; st.position.set(sg * 0.7, 1.42, 0.9);
    const mr = new T.Mesh(new T.CylinderGeometry(0.09, 0.09, 0.025, 20), rubberMat); mr.rotation.x = Math.PI / 2; mr.position.set(sg * 0.86, 1.52, 0.9);
    const gl = new T.Mesh(new T.CircleGeometry(0.078, 20), new T.MeshStandardMaterial({ color: 0x9fb8cc, roughness: 0.1, metalness: 0.9 })); gl.rotation.y = Math.PI; gl.position.set(sg * 0.86, 1.52, 0.878);
    driverAvatar.add(st, mr, gl);
  }
  // ---- Driver cockpit frame (matches the reference photo): yellow canopy and windshield frame, round mirrors, wiper, dark dash ----
  const driverRig = new T.Group();
  const yelMat = new T.MeshStandardMaterial({ color: 0xf2b705, roughness: 0.45 });
  const dashMat = new T.MeshStandardMaterial({ color: 0x14161a, roughness: 0.8 });
  const box = (w, h, d, x, y, z, m) => { const o = new T.Mesh(new T.BoxGeometry(w, h, d), m); o.position.set(x, y, z); driverRig.add(o); return o; };
  box(1.36, 0.065, 0.05, 0, 1.815, 0.90, yelMat);          // header
  box(1.36, 0.02, 0.06, 0, 1.775, 0.89, dashMat);        // rubber seal top
  box(1.36, 0.045, 0.10, 0, 1.06, 0.90, yelMat);          // lower frame
  box(1.36, 0.10, 0.12, 0, 1.005, 0.90, dashMat);          // dark dash cowl
  box(1.36, 0.10, 0.12, 0, 0.90, 0.89, dashMat);
  box(1.16, 0.09, 0.30, 0, 0.845, 0.80, dashMat);          // dark dash
  const link = (x1, y1, z1, x2, y2, z2, r, m) => { const v = new T.Vector3(x2 - x1, y2 - y1, z2 - z1); const o = new T.Mesh(new T.CylinderGeometry(r, r, v.length(), 8), m); o.position.set((x1 + x2) / 2, (y1 + y2) / 2, (z1 + z2) / 2); o.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), v.normalize()); driverRig.add(o); return o; };
  for (const sg of [-1, 1]) {
    box(0.042, 0.70, 0.045, sg * 0.655, 1.44, 0.90, yelMat);  // pillars
    box(0.025, 0.70, 0.06, sg * 0.62, 1.43, 0.89, dashMat); // rubber seal side
    link(sg * 0.60, 1.38, 0.84, sg * 0.89, 1.24, 0.88, 0.009, steelMat); // mirror stalk
    const rim = new T.Mesh(new T.CylinderGeometry(0.058, 0.058, 0.025, 24), dashMat); rim.rotation.x = Math.PI / 2; rim.position.set(sg * 0.60, 1.40, 0.84); driverRig.add(rim);
    const glass = new T.Mesh(new T.CircleGeometry(0.048, 24), new T.MeshStandardMaterial({ color: 0x55677a, roughness: 0.1, metalness: 0.9 })); glass.rotation.y = Math.PI; glass.position.set(sg * 0.60, 1.40, 0.826); driverRig.add(glass);
  }
  box(1.36, 0.04, 0.07, 0, 1.085, 0.89, dashMat);          // rubber seal bottom
  box(1.24, 0.36, 0.05, 0, 0.93, 0.60, dashMat);           // front interior bulkhead panel
  box(1.24, 0.05, 0.05, 0, 1.12, 0.60, yelMat);            // thin body-colour strip atop bulkhead
  // wiper: pivot low centre, blade arcing across the glass
  link(-0.05, 1.075, 0.87, -0.42, 1.13, 0.87, 0.013, dashMat);
  link(-0.05, 1.075, 0.87, 0.32, 1.13, 0.87, 0.013, dashMat);
  driverRig.position.z = 0.35; driverRig.visible = false;

  const attachTarget = (carGroup && carGroup.userData && carGroup.userData.chassis) ? carGroup.userData.chassis : carGroup;
  if (attachTarget) {
    attachTarget.add(cockpitGroup);
    attachTarget.add(driverAvatar);
    attachTarget.add(driverRig);
  }

  let currentIdx = 0;
  let prevIdx = 0;
  let blend = 1.0; // 0..1 over 0.6s transition
  let camRoll = 0;
  let bobPhase = 0;
  const listeners = [];

  const chasePos = new T.Vector3();
  let _prevAutoX = null, _prevAutoZ = null;
  const chaseLook = new T.Vector3();

  function updateButtonLabel() {
    const modeName = MODES[currentIdx];
    if (camBtn) {
      camBtn.innerHTML = `${CAM_ICON}<b>View:</b> <span>${MODE_LABELS[modeName]}</span> <i class="kbd">(V)</i>`;
    }
  }

  function applyVisibilityForMode(mode) {
    cockpitGroup.visible = mode === 'driver' || mode === 'passenger';
    driverAvatar.visible = mode === 'passenger';
    driverRig.visible = mode === 'driver';
    if (attachTarget) attachTarget.traverse(o => { if (o.userData && o.userData.hideDriver) o.visible = !(mode === 'driver' || mode === 'passenger'); if (o.userData && o.userData.hideInDriver) o.visible = mode !== 'driver'; });
  }

  function computePoseForMode(mode, dt, snap, outPos, outLook) {
    const spd = Math.abs(auto.v || 0);
    const steer = auto.steer || 0;
    const sinA = Math.sin(auto.a || 0);
    const cosA = Math.cos(auto.a || 0);

    if (mode === 'chase') {
      const back = 6.4; // Somil 16:22: keep camera-auto distance constant moving vs stopped
      const sideSwing = snap ? 0 : steer * ((auto.v || 0) / 17) * 1.4;
      const tx = auto.x - sinA * back + cosA * sideSwing;
      const tz = auto.z - cosA * back - sinA * sideSwing;
      const bounceY = snap ? 0 : Math.sin(bobPhase * 1.1) * spd * 0.008;
      const ty = (auto.y||0) + 2.7 + spd * 0.02 + bounceY;

      if (snap) {
        chasePos.set(tx, ty, tz);
        _prevAutoX = auto.x; _prevAutoZ = auto.z;
      } else {
        // Feed-forward the auto's own displacement, then smooth only the residual:
        // camera-auto distance stays ~constant at any speed (Somil 16:22 recede fix).
        if (_prevAutoX === null) { _prevAutoX = auto.x; _prevAutoZ = auto.z; }
        chasePos.x += auto.x - _prevAutoX;
        chasePos.z += auto.z - _prevAutoZ;
        _prevAutoX = auto.x; _prevAutoZ = auto.z;
        const kc = Math.min(1, dt * 5.0);
        chasePos.x += (tx - chasePos.x) * kc;
        chasePos.z += (tz - chasePos.z) * kc;
        chasePos.y += (ty - chasePos.y) * Math.min(1, dt * 3.8);
      }

      const lookAhead = 6.5;
      const sideLook = snap ? 0 : steer * 1.1;
      chaseLook.set(
        auto.x + sinA * lookAhead - cosA * sideLook,
        (auto.y||0)+1.0,
        auto.z + cosA * lookAhead + sinA * sideLook
      );

      outPos.copy(chasePos);
      outLook.copy(chaseLook);
      return {
        fov: 54 + spd * 0.72,
        roll: snap ? 0 : -steer * (auto.v || 0) * 0.0028
      };
    }

    // World-space transform from carGroup (accounting for 1.22 carGroup scale and suspension pitch/roll)
    const scale = carGroup ? carGroup.scale.x : 1.05;
    const bob = Math.sin(bobPhase * 1.4) * Math.min(0.004, spd * 0.00025);

    if (mode === 'driver') {
      // Driver head position just behind handlebar (~1.38m local * scale, looking straight out through windshield)
      const localX = -steer * 0.06;
      const localY = (1.30 + bob) * scale;
      const localZ = 0.22 * scale;
      outPos.set(
        auto.x + cosA * localX + sinA * localZ,
        (auto.y||0)+localY,
        auto.z - sinA * localX + cosA * localZ
      );
      outLook.set(
        auto.x + sinA * 18.0 - cosA * (steer * 2.2),
        (auto.y||0)+localY - 0.18,
        auto.z + cosA * 18.0 + sinA * (steer * 2.2)
      );
      return {
        fov: 64 + spd * 0.85,
        roll: -steer * (auto.v || 0) * 0.0045
      };
    }

    // 'passenger' back-seat view: seated on rear bench looking slightly over the driver's right shoulder
    const pLocalX = 0.0 * scale + steer * 0.02;
    const pLocalY = (1.52 + bob * 1.0) * scale;
    const pLocalZ = -0.56 * scale;
    outPos.set(
      auto.x + cosA * pLocalX + sinA * pLocalZ,
      (auto.y||0)+pLocalY,
      auto.z - sinA * pLocalX + cosA * pLocalZ
    );
    outLook.set(
      auto.x + sinA * 14.0 - cosA * (steer * 1.5 - 0.15),
      (auto.y||0)+pLocalY - 3.2,
      auto.z + cosA * 14.0 + sinA * (steer * 1.5 - 0.15)
    );
    return {
      fov: 56 + spd * 0.5,
      roll: -steer * (auto.v || 0) * 0.0038
    };
  }

  function set(name) {
    const idx = MODES.indexOf(name);
    if (idx === -1 || idx === currentIdx) return;
    prevIdx = currentIdx;
    currentIdx = idx;
    blend = 0.0;
    applyVisibilityForMode(MODES[currentIdx]);
    updateButtonLabel();
    for (const cb of listeners) cb(MODES[currentIdx]);
  }

  function next() {
    const nextMode = MODES[(currentIdx + 1) % MODES.length];
    set(nextMode);
    return nextMode;
  }

  speedPanel.querySelector('#drive-prev').addEventListener('click', () => set(MODES[(currentIdx + MODES.length - 1) % MODES.length]));
  speedPanel.querySelector('#drive-next').addEventListener('click', () => next());
  if (camBtn) camBtn.addEventListener('click', () => next());
  window.addEventListener('keydown', (e) => {
    if (e.code === 'KeyV' && (!document.activeElement || document.activeElement.tagName !== 'INPUT')) {
      next();
    }
  });

  applyVisibilityForMode(MODES[currentIdx]);
  updateButtonLabel();

  const posA = new T.Vector3(), lookA = new T.Vector3();
  const posB = new T.Vector3(), lookB = new T.Vector3();
  const finalPos = new T.Vector3(), finalLook = new T.Vector3();

  const look = { yaw: 0, pitch: 0, ty: 0, tp: 0, drag: false, x: 0, y: 0 };
  const cv = camera && document.querySelector('canvas');
  const dn = (e) => { if (e.target && e.target.tagName && e.target.tagName !== 'CANVAS') return; look.drag = true; look.x = e.clientX; look.y = e.clientY; };
  const mv = (e) => { if (!look.drag) return; const dx = e.clientX - look.x, dy = e.clientY - look.y; look.x = e.clientX; look.y = e.clientY;
    look.ty = T.MathUtils.clamp(look.ty + dx * 0.006, -1.3, 1.3); look.tp = T.MathUtils.clamp(look.tp + dy * 0.004, -0.3, 0.3); };
  const up = () => { look.drag = false; };
  window.addEventListener('pointerdown', dn); window.addEventListener('pointermove', mv);
  window.addEventListener('pointerup', up); window.addEventListener('pointercancel', up);
  function applyLook(dt) {
    if (MODES[currentIdx] === 'chase') { look.ty = look.tp = look.yaw = look.pitch = 0; return; }
    if (!look.drag) { const k = Math.min(1, dt * 2.5); look.ty -= look.ty * k; look.tp -= look.tp * k; }
    look.yaw += (look.ty - look.yaw) * Math.min(1, dt * 14 + 0.01); look.pitch += (look.tp - look.pitch) * Math.min(1, dt * 14 + 0.01);
    if (Math.abs(look.yaw) > 0.001 || Math.abs(look.pitch) > 0.001) { camera.rotateOnWorldAxis(new T.Vector3(0, 1, 0), -look.yaw); camera.rotateX(-look.pitch); }
  }
  function update(dt = 0.016, snap = false) {
    const mph=Math.round(Math.abs(auto.v)*2.2369362921);
    speedPanel.querySelector('#drive-speed').textContent=String(mph);
    speedPanel.querySelector('#drive-fill').style.width=(100*Math.abs(auto.v)/(Math.abs(auto.v)+25))+'%';
    bobPhase += dt * (10 + Math.abs(auto.v || 0) * 1.6);
    cockpitBar.rotation.y = (auto.steer || 0) * 0.48;
    driverAvatar.rotation.z = -(auto.steer || 0) * 0.12;
    drawSpeedo(Math.abs(auto.v || 0) * 3.6);

    if (snap) {
      blend = 1.0;
      const cur = computePoseForMode(MODES[currentIdx], dt, true, finalPos, finalLook);
      camera.position.copy(finalPos);
      camera.up.set(0, 1, 0);
      camera.lookAt(finalLook);
      applyLook(0.016);
      camera.fov = cur.fov;
      camera.updateProjectionMatrix();
      camRoll = 0;
      return;
    }

    // Keep chasePos warm even while in interior modes so switching back is seamless
    if (MODES[currentIdx] !== 'chase') {
      computePoseForMode('chase', dt, false, posA, lookA);
    }

    const curPose = computePoseForMode(MODES[currentIdx], dt, false, posB, lookB);

    if (blend < 1.0) {
      blend = Math.min(1.0, blend + dt / 0.6);
      const t = blend * blend * (3.0 - 2.0 * blend); // Smoothstep 0.6s transition
      const prevPose = computePoseForMode(MODES[prevIdx], dt, false, posA, lookA);
      finalPos.lerpVectors(posA, posB, t);
      finalLook.lerpVectors(lookA, lookB, t);
      const targetFov = T.MathUtils.lerp(prevPose.fov, curPose.fov, t);
      const targetRoll = T.MathUtils.lerp(prevPose.roll, curPose.roll, t);
      camera.fov += (targetFov - camera.fov) * Math.min(1, dt * 8);
      camRoll += (targetRoll - camRoll) * Math.min(1, dt * 8);
    } else {
      finalPos.copy(posB);
      finalLook.copy(lookB);
      camera.fov += (curPose.fov - camera.fov) * Math.min(1, dt * 5);
      camRoll += (curPose.roll - camRoll) * Math.min(1, dt * 6);
    }

    camera.position.copy(finalPos);
    camera.up.set(0, 1, 0);
    camera.lookAt(finalLook);
    if (Math.abs(camRoll) > 0.0001) camera.rotateZ(camRoll);
    applyLook(dt);
    camera.updateProjectionMatrix();
  }

  return {
    next,
    set,
    get name() { return MODES[currentIdx]; },
    update,
    onChange(cb) { if (typeof cb === 'function') listeners.push(cb); }
  };
}
