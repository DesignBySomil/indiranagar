// Read-only audit query. A missing source footprint is not proof a space is empty.
export function createExtensionQuery(data){
 const cells=new Map(),size=20;for(const b of data.buildings){const xs=b.points.map(p=>p[0]),zs=b.points.map(p=>p[1]);for(let x=Math.floor(Math.min(...xs)/size);x<=Math.floor(Math.max(...xs)/size);x++)for(let z=Math.floor(Math.min(...zs)/size);z<=Math.floor(Math.max(...zs)/size);z++){const k=x+','+z;if(!cells.has(k))cells.set(k,[]);cells.get(k).push(b);}}
 return(x,z,y,roof=2.2)=>{const matches=[];for(const b of cells.get(Math.floor(x/size)+','+Math.floor(z/size))||[]){let inside=false;for(let i=0,j=b.points.length-1;i<b.points.length;j=i++){const a=b.points[i],c=b.points[j];if((a[1]>z)!==(c[1]>z)&&x<(c[0]-a[0])*(z-a[1])/(c[1]-a[1])+a[0])inside=!inside;}if(inside&&y+roof>=0&&y<=b.height)matches.push(b.id);}return{blocked:!!matches.length,matches,scope:'provisional source footprints only'};};
}
