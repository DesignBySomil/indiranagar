import * as THREE from 'three';
// Explicit audit visualization, not accepted scenery or source height claims.
export function renderDomlurBuildingAudit(data,scene){
 const group=new THREE.Group();group.name='AUDIT ONLY provisional building heights';
 const material=new THREE.MeshStandardMaterial({color:0x977c68,roughness:.95});
 for(const b of data.buildings){const shape=new THREE.Shape(b.points.map(p=>new THREE.Vector2(p[0],-p[1]))),g=new THREE.ExtrudeGeometry(shape,{depth:b.height,bevelEnabled:false});g.rotateX(-Math.PI/2);const mesh=new THREE.Mesh(g,material);mesh.name='OSM '+b.id+' height '+b.height+' PROVISIONAL';mesh.userData.sourceId=b.id;mesh.castShadow=true;mesh.receiveShadow=true;group.add(mesh);}
 scene.add(group);return group;
}
