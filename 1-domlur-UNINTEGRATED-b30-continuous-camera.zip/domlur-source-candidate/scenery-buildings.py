# Source footprints; game heights default10m, NOT surveyed and not enabled for driving.
import json,math
from shapely.geometry import Polygon,LineString
m=json.load(open('/tmp/deep-research/domlur/merged-map.json'));world=json.load(open('public/data/world.json'));lat0,lon0=world['lat0'],world['lon0']
# Recover exact projection from an existing source road point, not a second coordinate origin.
refs=[(m['nodes'][n],p)for w in m['roads']for n,p in zip(w['nodes'],w['p'])];lx=sum((p[0]/(ll[1]-lon0))for ll,p in refs if abs(ll[1]-lon0)>.0001)/sum(abs(ll[1]-lon0)>.0001 for ll,p in refs);lz=sum((p[1]/(lat0-ll[0]))for ll,p in refs if abs(lat0-ll[0])>.0001)/sum(abs(lat0-ll[0])>.0001 for ll,p in refs)
# Fit coordinate scale against all source roads and verify residual against rounding.
lx=sum((ll[1]-lon0)*p[0]for ll,p in refs)/sum((ll[1]-lon0)**2 for ll,p in refs)
lz=sum((lat0-ll[0])*p[1]for ll,p in refs)/sum((lat0-ll[0])**2 for ll,p in refs)
error=max(math.hypot(round((ll[1]-lon0)*lx,1)-p[0],round((lat0-ll[0])*lz,1)-p[1])for ll,p in refs);assert error<.15,error
out=[];missing=0
for w in m['ways']:
 if 'building'not in w['tags']:continue
 if any(n not in m['nodes']for n in w['nodes']):missing+=1;continue
 pts=[[round((m['nodes'][n][1]-lon0)*lx,1),round((lat0-m['nodes'][n][0])*lz,1)]for n in w['nodes']];poly=Polygon(pts)
 if not poly.is_valid or poly.area<12 or not(-800<poly.centroid.x<800 and 950<poly.centroid.y<2250):continue
 out.append({'id':w['id'],'points':pts,'height':10,'heightSource':'provisional-game-default','sourceTags':{k:v for k,v in w['tags'].items()if k in ['building','height','building:levels']}})
json.dump({'scope':'Read-only collision preparation. No rendering or driving use. Footprints OSM, all heights provisional10m.','projectionMaxError':error,'missingNodeWays':missing,'buildings':out},open('public/data/domlur-buildings-expanded.json','w'));print({'count':len(out),'missing':missing,'projectionMaxError':error})
