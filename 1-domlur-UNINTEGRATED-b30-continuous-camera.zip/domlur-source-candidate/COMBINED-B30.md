# Unintegrated Domlur candidate batch 30

Expanded source footprint scenery extent from 1618 to 1850 footprints using retained OSM data, game heights unchanged for all previously included footprints. Ground-road scenery extent expanded too. Elevated surroundings still show large sparse areas; not scene-ready. Camera clearance now includes the same creative pier cylinders as rendering.

Continuous main-physics ramp-to-north run with movers on and actual camera rig switching mode every 180 ticks: 1375.673976m, all48nodes,8265ticks,0movementblocks,0camera-point overlaps with candidate building/slab/rail/pier volumes. All3modes and their normal blend transitions exercised. The trace remains identical to the prior run. This covers only the ramp route, and camera-point checks do not prove all view rays/near-plane clearance or moving actor/accepted-decoration clearance. No physical device acceptance.

Expanded-extent elevated chase pixels inspected. Buildings now extend farther across the horizon, but empty terrain remains too obvious. This is progress, not readiness. No production/accepted source changes. Local patch, not remote yet.
