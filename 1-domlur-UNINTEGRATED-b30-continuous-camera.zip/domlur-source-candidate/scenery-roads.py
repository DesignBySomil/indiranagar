import json
from shapely.geometry import LineString,box
from shapely.ops import unary_union,triangulate
m=json.load(open('/tmp/deep-research/domlur/merged-map.json'));out={'scope':'OSM ground-road scenery only, game widths. Route-only driving support remains unchanged.','asphalt':[],'shoulders':[]};polys=[];shoulders=[]
for r in m['roads']:
 t=r['tags']
 if t.get('bridge')=='yes' or float(t.get('layer','0'))>0 or t.get('highway')in ['footway','path','steps','cycleway']:continue
 width={'primary':7,'secondary':6,'tertiary':5,'residential':4,'service':3,'unclassified':4}.get(t.get('highway'),4)
 if len(r['p'])<2:continue
 line=LineString(r['p']);polys.append(line.buffer(width/2,join_style=2));shoulders.append(line.buffer(width/2+.9,join_style=2))
for key,ps in [('asphalt',polys),('shoulders',shoulders)]:
 geom=unary_union(ps).intersection(box(-800,1000,800,2250))
 for tri in triangulate(geom):
  if geom.covers(tri):
   for x,z in list(tri.exterior.coords)[:3]:out[key].extend([x,0,z])
json.dump(out,open('public/data/domlur-scenery-roads.json','w'));print({k:len(out[k])//9 for k in ['asphalt','shoulders']})
