# Unintegrated Domlur candidate batch 29

Candidate-only camera clearance checks the same source footprint heights and rendered slab/rail geometry. Chase camera shortens its boom on an obstruction. Interior cameras retain the existing rig. Accepted ground clamp remains unchanged; this path is used only while attached to the explicit candidate.

Route pose scan: 4203 centerline camera samples across all three routes at 3m intervals, three camera modes, no camera-point overlap with candidate building/slab/rail volumes. Additional 8892 offset/reverse samples (9m spacing, offsets -1.4/0/1.4m, both headings, three modes) also show no point overlap. These are static snapped-pose checks, not continuous drive/transition proof. The guard did not activate in these route samples. Synthetic building obstruction fixture does activate it and leaves the camera outside the volume.

Actual main-physics drive to the elevated curve, followed by chase/driver/passenger render, inspected again. Road visible. Sparse elevated surroundings remain visible and scene continuity is not finished. Camera model does not yet cover piers, moving actors or all accepted-city decorations. No physical-device acceptance.

Includes prior mixed-height actual-provider targeting fixtures: 18 nearer wrong-height / farther correct-height cases pass. Parked provider is null in current runtime, unchanged. No game authority inferred from the preexisting code comment about its removal.

No production or accepted source/map changes. Local patch, not yet remote-preserved.
