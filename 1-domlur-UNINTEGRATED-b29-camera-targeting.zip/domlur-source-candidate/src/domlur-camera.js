import {createExtensionQuery} from './domlur-extension-query.js';
// Candidate-only camera clearance uses the same footprint heights, slab surfaces
// and rail segments as rendering. It does not treat an underpass as a 2D wall.
export function createDomlurCameraClearance(buildings,joined){
 const building=createExtensionQuery(buildings),cells=new Map(),size=12;
 const add=(item,xs,zs)=>{for(let x=Math.floor(Math.min(...xs)/size);x<=Math.floor(Math.max(...xs)/size);x++)for(let z=Math.floor(Math.min(...zs)/size);z<=Math.floor(Math.max(...zs)/size);z++){const key=x+','+z;if(!cells.has(key))cells.set(key,[]);cells.get(key).push(item);}};
 for(const r of Object.values(joined.routes)){if(r.ground)continue;for(const t of r.triangles)add({t},t.map(p=>p[0]),t.map(p=>p[2]));for(const[a,b]of r.railSegments||[])add({a,b},[a[0],b[0]],[a[2],b[2]]);}
 function blocked(x,y,z){if(building(x,z,y-.18,.36).blocked)return true;
  for(const o of cells.get(Math.floor(x/size)+','+Math.floor(z/size))||[]){if(o.t){const[a,b,c]=o.t,den=(b[2]-c[2])*(a[0]-c[0])+(c[0]-b[0])*(a[2]-c[2]);if(Math.abs(den)<1e-8)continue;const u=((b[2]-c[2])*(x-c[0])+(c[0]-b[0])*(z-c[2]))/den,v=((c[2]-a[2])*(x-c[0])+(a[0]-c[0])*(z-c[2]))/den;if(u<0||v<0||u+v>1)continue;const h=u*a[1]+v*b[1]+(1-u-v)*c[1];if(y>h-.58&&y<h+.18)return true;
   }else{const{a,b}=o,dx=b[0]-a[0],dz=b[2]-a[2],t=Math.max(0,Math.min(1,((x-a[0])*dx+(z-a[2])*dz)/(dx*dx+dz*dz||1))),h=a[1]+t*(b[1]-a[1]);if(y>h-.58&&y<h+.83&&Math.hypot(x-a[0]-t*dx,z-a[2]-t*dz)<.2)return true;}}
  return false;
 }
 function correct(camera,auto,mode){if(mode!=='chase')return false;const target={x:auto.x,y:(auto.y||0)+1.1,z:auto.z},p=camera.position,dx=p.x-target.x,dy=p.y-target.y,dz=p.z-target.z,L=Math.hypot(dx,dy,dz);for(let s=.65;s<=L;s+=.15){const t=s/L;if(blocked(target.x+dx*t,target.y+dy*t,target.z+dz*t)){const q=Math.max(.55,s-.35)/L;p.set(target.x+dx*q,target.y+dy*q,target.z+dz*q);camera.lookAt(target.x,target.y,target.z);return true;}}return false;}
 return{blocked,correct};
}
