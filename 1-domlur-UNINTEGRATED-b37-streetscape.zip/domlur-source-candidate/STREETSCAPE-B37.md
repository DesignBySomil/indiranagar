# Unintegrated batch37: surrounding ground-road continuity

Fixed the most visible disconnected ground-road fragments: the ground-road mesh was only9mm above terrain, causing distance depth-fighting. Candidate source asphalt now draws55mm above ground with shoulders35mm, visual only. Source ground roads use coherent game widths and constrained triangulation without discarding boundary triangles by floating-point covers checks.

Reused accepted city's createRainTrees assets along source ground roads, excluded15m from candidate route centerlines and source building occupancy. Candidate-only tree group. Existing accepted world unchanged. Main actual-drive noon pixels inspected at200m curve and450m descent: ground roads now read continuously and accepted-language trees connect the surrounding streets. Large basic/empty areas remain, so this is not finished visual acceptance.

Tree placement is game scenery, not surveyed tree positions. Candidate source roads still do not grant extra driving support outside route corridors. No physical device, actor-camera or full scene-collision acceptance. No production changes. Local patch not yet remote-preserved.
