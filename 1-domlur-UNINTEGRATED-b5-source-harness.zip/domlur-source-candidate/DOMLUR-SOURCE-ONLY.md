# SOURCE-ONLY opt-in harness, not an implemented flyover
Base: original boundary candidate 3bcd1e7f53fbcfbaf18af44d26636ff5a2598fad.
No production, accepted tree or normal-game map changes.

New QA-only load/attach entry points exercise the support adapter in a separate early-return branch. They deliberately do not integrate rendering, camera, traffic, impacts, recovery or scenery. Do not deploy this as a finished feature.

Default ground path regression: 16697 simulation steps, 31 loop nodes, 1403.662591 m travel, 0 recoveries. Full trace JSON exactly equals the accepted baseline (including all positions, velocities and metrics). This covers one loop with movers disabled, not every ground behavior.

Adapter standalone support: north4781,airport5308,south4797 samples using the existing game's seven body-probe offsets. These are not input-driven game drives. No grade pitch, dynamic collisions, branch switches or attached-road renderer yet. Game heights and width are provisional, not surveyed.
