// Unintegrated contract. Caller supplies real collider bounds; no invented object heights.
export function overlap(a,b){return a.min<=b.max&&b.min<=a.max;}
export function vertical(y,bodyHeight){if(!Number.isFinite(y)||!Number.isFinite(bodyHeight)||bodyHeight<=0)throw Error('invalid body interval');return{min:y,max:y+bodyHeight};}
export function relevant(body,collider,{groundLegacy=false}={}){
 if(!collider.enabled)return false;
 if(!Number.isFinite(collider.yMin)||!Number.isFinite(collider.yMax))return groundLegacy||'unknown';
 if(collider.yMin>collider.yMax)throw Error('invalid collider interval');
 return overlap(body,{min:collider.yMin,max:collider.yMax});
}
export function contact(body,colliders,opts){
 let kind=0,unknown=[];
 for(const c of colliders){const yes=relevant(body,c,opts);if(yes==='unknown'){unknown.push(c.id);continue;}if(yes&&c.planHit)kind=Math.max(kind,c.static?2:1);}
 // Unknown bounds are a blocking integration error, never invisible permission to pass through.
 return{blocked:kind>0||unknown.length>0,kind:kind===2?'static':kind===1?'dynamic':'none',unknown};
}
export function canImpact(body,target){return relevant(body,target)===true&&target.planHit===true;}
export function recoveryAllowed(current,candidate){return current.surface===candidate.surface&&current.level===candidate.level&&candidate.supported===true;}
