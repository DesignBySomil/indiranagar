import json,math
import numpy as np
from shapely.geometry import LineString,Polygon,Point
m=json.load(open('/tmp/domlur-surface-prototype/network.json'));nodes=m['nodes'];j=json.load(open('/tmp/domlur-surface-prototype/joined.json'));source=json.load(open('/tmp/deep-research/domlur/merged-map.json'))
def body(x,z,yaw):
 ux,uz=math.sin(yaw),math.cos(yaw)
 return Polygon([(x+u*ux+v*uz,z+u*uz-v*ux) for u,v in[(-1.4,-.8),(1.4,-.8),(1.4,.8),(-1.4,.8)]])
rows=[]
for name,r in m['routes'].items():
 pts=[nodes[n]['p'] for n in r['nodes']];poly=Polygon(j['routes'][name]['boundary']);bad=[];samples=0;maxturn=0
 for i in range(1,len(pts)-1):
  a,p,b=pts[i-1:i+2];yin=math.atan2(p[0]-a[0],p[1]-a[1]);yout=math.atan2(b[0]-p[0],b[1]-p[1]);delta=(yout-yin+math.pi)%(2*math.pi)-math.pi;maxturn=max(maxturn,abs(delta))
  # Conservative in-place rotation at each node. This is not vehicle steering dynamics.
  for t in np.linspace(0,1,max(2,math.ceil(abs(delta)/math.radians(.5)))):
   samples+=1
   if not poly.covers(body(*p,yin+delta*t)):bad.append(i)
 # Subdivided moving body with interpolated yaw over each segment, bounded sample not swept proof.
 moving=0;movingBad=0
 headings=[math.atan2(b[0]-a[0],b[1]-a[1]) for a,b in zip(pts,pts[1:])]
 for i,(a,b) in enumerate(zip(pts,pts[1:])):
  l=math.dist(a,b);h=headings[i];h0=headings[i-1] if i else h;h1=headings[i+1] if i+1<len(headings) else h
  d0=(h0-h+math.pi)%(2*math.pi)-math.pi;d1=(h1-h+math.pi)%(2*math.pi)-math.pi
  for at in np.linspace(0,l,max(2,math.ceil(l/.1))):
   t=at/l;yaw=h+(d0*.5*(1-at/2) if at<2 else d1*.5*(1-(l-at)/2) if l-at<2 else 0)
   moving+=1;movingBad+=not poly.covers(body(a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,yaw))
 rows.append({'movingPoses':moving,'movingFailures':movingBad,'route':name,'nodeRotationSamples':samples,'failures':len(bad),'maxNodeTurnDegrees':math.degrees(maxturn)})
# Exact plan intersections with mapped HAL Old Airport Road; height remains provisional.
clear=[]
for name,r in m['routes'].items():
 for aa,bb in zip(r['nodes'],r['nodes'][1:]):
  a,b=nodes[aa],nodes[bb];line=LineString([a['p'],b['p']])
  for w in source['roads']:
   if w['tags'].get('name')!='HAL Old Airport Road':continue
   for p,q in zip(w['p'],w['p'][1:]):
    cross=line.intersection(LineString([p,q]))
    if cross.is_empty or cross.geom_type!='Point':continue
    t=line.project(cross)/line.length;y=a['y']+(b['y']-a['y'])*t
    clear.append({'route':name,'way':w['id'],'x':cross.x,'z':cross.y,'gameSurfaceY':y,'sharedGroundEndpoint':aa in w['nodes'] or bb in w['nodes']})
result={'scope':'Node rotation containment and plan crossing audit, not physics/real clearance','rotations':rows,'airportRoadIntersections':clear,'gameDeckUndersideAssumingThickness0_4m':6.4,'surveyClearanceKnown':False}
json.dump(result,open('/tmp/domlur-surface-prototype/sweep-results.json','w'),indent=2);print(json.dumps(result,indent=2))
