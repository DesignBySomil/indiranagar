# Unintegrated batch35: source building coverage transition

Extended candidate source footprint preparation from centroidZ950 down toZ790, adding303footprints after excluding intersections with accepted source building polygons buffered0.5m. Renderer threshold is now all verticesZ>795 instead ofZ>1000, beyond the accepted source footprint maximumZ792.7. Source ground-road scenery extends toZ795 as well. Existing accepted source remains unchanged. Candidate collision and camera queries use the expanded source envelopes, game heights unchanged for earlier footprints.

Noon main-drive images at1000m and1200m inspected: previous empty building corridor is filled, the new facades now continue behind accepted street trees into the old city. The art remains simpler than accepted facades, and the elevated scene still needs work. Not overall acceptance.

Full ramp main-physics movers-on route with actual camera blending re-run after footprint expansion: see main-camera-continuous-results.json. No physical-device, near-plane/view-ray or all-actor camera proof. No production or accepted-source change. Local patch, not remote yet.
