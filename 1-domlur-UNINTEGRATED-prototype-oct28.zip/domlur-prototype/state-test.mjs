import assert from'node:assert/strict';import fs from'node:fs';import{net,edges,out,pose,advance,attach}from'./state.mjs';
let transitions=0,samples=0,maxDy=0,denied=0;
for(const e of edges){for(const next of out.get(e.b)||[]){let st={edge:e.id,s:Math.max(0,e.len-.1)},before=pose(st);let q=advance(st,.2,next);assert(q);let after=pose(q);assert(Math.hypot(after.x-before.x,after.z-before.z)<=.200001);assert(Math.abs(after.y-before.y)<.04);transitions++;}
 for(const wrong of edges.filter(q=>q.a!==e.b).slice(0,5)){assert.equal(advance({edge:e.id,s:e.len-.01},.02,wrong.id),null);denied++;}
 let prev=pose({edge:e.id,s:0});for(let s=.2;s<=e.len;s+=.2){let p=pose({edge:e.id,s});maxDy=Math.max(maxDy,Math.abs(p.y-prev.y));prev=p;samples++;}
}
for(const[n,v]of Object.entries(net.nodes))if(!net.externalGroundNodes.includes(n))assert.equal(attach(n),null);
let report={scope:'Directed graph/support-state unit tests only, not steering or game physics',edges:edges.length,legalEndpointTransitions:transitions,wrongEndpointTransitionsRejected:denied,edgeSamples:samples,maxDy,groundAttachOnlyAtDeclaredEndpoints:true,reverseNotImplemented:true};
fs.writeFileSync(new URL('./state-results.json',import.meta.url),JSON.stringify(report,null,2));console.log(report);
