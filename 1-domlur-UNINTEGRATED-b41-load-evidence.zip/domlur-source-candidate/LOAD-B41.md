# Unintegrated batch41: second-load invariance evidence

No game source changes. After first candidate load and northbound attach, second load returns the same three routes and leaves74top-level scene UUIDs/order plus serialized auto/candidate state unchanged. This is sequential second-load evidence, not concurrent initial-load evidence.

Fresh north combined scenery drive remains unverified after local run timeouts. No managed persistent local process facility is available in the current execution surface; no more unchanged full-run retries or reduced-scene acceptance claimed. Earlier north pass remains separate. Parent owns the unresolved full-scene north test path.

Ramp/south fresh combined passes remain in batch40. Visual quality, broader camera/device acceptance remain open. No production or accepted source changes.
