# Unintegrated batch 31: remaining continuous camera routes

No game source changes in this batch. Main-physics movers-on routes now all complete with actual three-camera switching through normal blends every180ticks. Candidate-camera-point checks include source building envelopes and rendered slab/rail/pier volumes.

- Ramp-to-north:48nodes,1375.673976m,8265ticks,0blocks,0camera-point overlaps (batch30).
- Southbound:26nodes,1325.063962m,7962ticks,0blocks,0camera-point overlaps.
- Northbound:27nodes,1322.870286m,7949ticks,0blocks,0camera-point overlaps.

All three traces match earlier driving-only results. This is not view-ray/near-plane/actor/accepted-decoration or device acceptance. Sparse scenery remains unfinished. Accepted source/production unchanged. This is a local test patch, not remote-preserved yet.
