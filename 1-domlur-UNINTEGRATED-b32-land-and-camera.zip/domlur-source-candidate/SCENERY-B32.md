# Unintegrated batch 32: source land surfaces and remaining camera tests

129 retained OSM landuse/leisure/water polygons rendered with a muted game palette. Visual only, no new driving support. Uses constrained triangulation rather than filtering unconstrained triangles, preserving source polygon coverage and holes. Ground-road scenery now uses the same constrained triangulation.

Elevated main-drive chase pixels inspected after the change: no render failure, source land patches replace the uniform blank terrain, but scene still looks sparse and is not ready for review as a finished Domlur extension. No invented extra source buildings used to conceal the gap.

Includes batch31 remaining continuous-camera route tests. All3fullroutes with actual camera mode blending complete, zero movement blocks and candidate camera-point overlaps. Caveats remain in CONTINUOUS-B31.md. No physical-device acceptance or production/accepted source change.

Local patch, not remotely preserved yet. Source OSM references remain the two retained API extracts described in the candidate source notes. Game colors and dimensions are approximations, not surveyed appearance.
