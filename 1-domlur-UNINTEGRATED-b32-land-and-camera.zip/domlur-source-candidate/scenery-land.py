from shapely import constrained_delaunay_triangles
# Retained OSM landuse/leisure/water geometry; palette is a game choice.
import json
from shapely.geometry import Polygon,box
from shapely.ops import triangulate,unary_union
m=json.load(open('/tmp/deep-research/domlur/merged-map.json'));world=json.load(open('public/data/world.json'));lat0,lon0=world['lat0'],world['lon0']
refs=[(m['nodes'][n],p)for w in m['roads']for n,p in zip(w['nodes'],w['p'])];lx=sum((ll[1]-lon0)*p[0]for ll,p in refs)/sum((ll[1]-lon0)**2 for ll,p in refs);lz=sum((lat0-ll[0])*p[1]for ll,p in refs)/sum((lat0-ll[0])**2 for ll,p in refs)
colors={'residential':0x7d766b,'commercial':0x858078,'retail':0x8a8174,'industrial':0x777875,'construction':0x9b8871,'greenfield':0x77775b,'park':0x626e4e,'scrub':0x747252,'pitch':0x7e825f,'water':0x526a70,'playground':0x8a7d65,'garden':0x687657,'grass':0x758060,'wood':0x58634b,'religious':0x8d8478,'cemetery':0x7e806c,'recreation_ground':0x748064,'common':0x748064,'swimming_pool':0x587d87,'sports_centre':0x837c6e}
by={};ids=[]
for w in m['ways']:
 t=w['tags'];kind=t.get('landuse',t.get('leisure',t.get('natural','')))
 if kind not in colors or len(w['nodes'])<4 or w['nodes'][0]!=w['nodes'][-1] or any(n not in m['nodes']for n in w['nodes']):continue
 p=Polygon([((m['nodes'][n][1]-lon0)*lx,(lat0-m['nodes'][n][0])*lz)for n in w['nodes']])
 if not p.is_valid: p=p.buffer(0)
 p=p.intersection(box(-800,1000,800,2250))
 if p.is_empty:continue
 by.setdefault(kind,[]).append(p);ids.append(w['id'])
out=[]
for kind,polys in by.items():
 p=unary_union(polys);pos=[]
 for tri in constrained_delaunay_triangles(p).geoms:
  if p.covers(tri):
   for x,z in list(tri.exterior.coords)[:3]:pos.extend([x,0,z])
 out.append({'kind':kind,'color':colors[kind],'positions':pos})
json.dump({'scope':'OSM landuse/leisure/water source polygons, game palette; visual only, not drivable support or surveyed surface.','sourceWays':ids,'layers':out},open('public/data/domlur-land-scenery.json','w'));print(len(ids),[(p['kind'],len(p['positions'])//9)for p in out])
