// Isolated feasibility prototype. Heights/widths are GAME DESIGN values, not survey data.
export function buildSurface(points,{height=6.8,ramp=90,halfWidth=4.8}={}){
 let s=0;const segs=[];for(let i=1;i<points.length;i++){let a=points[i-1],b=points[i],len=Math.hypot(b[0]-a[0],b[1]-a[1]);if(!len)continue;segs.push({a,b,len,s0:s,s1:s+len});s+=len;}
 const total=s, smooth=t=>t*t*(3-2*t);
 const yAt=s=>height*Math.min(smooth(Math.max(0,Math.min(1,s/ramp))),smooth(Math.max(0,Math.min(1,(total-s)/ramp))));
 function candidates(x,z){return segs.map((g,i)=>{let dx=g.b[0]-g.a[0],dz=g.b[1]-g.a[1],t=Math.max(0,Math.min(1,((x-g.a[0])*dx+(z-g.a[1])*dz)/g.len**2));let px=g.a[0]+dx*t,pz=g.a[1]+dz*t,at=g.s0+t*g.len;return{i,s:at,x:px,z:pz,d:Math.hypot(x-px,z-pz),y:yAt(at),yaw:Math.atan2(dx,dz)}}).filter(q=>q.d<=halfWidth);}
 function support(x,z,previous,maxTravel=1){const q=candidates(x,z).filter(q=>previous?Math.abs(q.s-previous.s)<=maxTravel+1: q.s<2||q.s>total-2);q.sort((a,b)=>a.d-b.d);return q[0]||null;}
 return{segs,total,yAt,candidates,support,halfWidth};
}
