import json,math
import numpy as np
from shapely.geometry import LineString,Polygon
from shapely.ops import unary_union
m=json.load(open('/tmp/domlur-surface-prototype/network.json'));nodes=m['nodes'];w={r['id']:r for r in m['ways']}
# Prototype choices only. No dimensions claimed for the real flyover or game auto.
HALF_WIDTH=4.8;HALF_BODY=.8;HALF_LENGTH=1.4
# Shared-node elevations are interpolated along each segment. Connected ramps share exactly one value.
segs=[]
for way in m['ways']:
 for a,b in zip(way['nodes'],way['nodes'][1:]):
  aa,bb=nodes[a],nodes[b];segs.append((a,b,aa['p'],bb['p'],aa['y'],bb['y']))
def poly(x,z,yaw):
 dx,dz=math.sin(yaw),math.cos(yaw);nx,nz=dz,-dx
 return Polygon([(x+u*dx+v*nx,z+u*dz+v*nz) for u,v in [(-HALF_LENGTH,-HALF_BODY),(HALF_LENGTH,-HALF_BODY),(HALF_LENGTH,HALF_BODY),(-HALF_LENGTH,HALF_BODY)]])
# A local support corridor, never the union of different-height overlapping roads.
active_edges=set()
def corridor(x,z,y):
 out=[]
 for a,b,p,q,ya,yb in segs:
  if (a,b) not in active_edges:continue
  dx,dz=q[0]-p[0],q[1]-p[1];l=math.hypot(dx,dz);t=max(0,min(1,((x-p[0])*dx+(z-p[1])*dz)/l**2));sy=ya+(yb-ya)*t
  if abs(sy-y)<=.6 and math.hypot(x-p[0]-t*dx,z-p[1]-t*dz)<12:out.append(LineString([p,q]).buffer(HALF_WIDTH,cap_style=1))
 return unary_union(out)
checks=0;fails=[];maxstep=0
for name,r in m['routes'].items():
 active_edges=set(zip(r['nodes'],r['nodes'][1:]));prev=None
 for a,b in zip(r['nodes'],r['nodes'][1:]):
  aa,bb=nodes[a],nodes[b];p,q=aa['p'],bb['p'];dx,dz=q[0]-p[0],q[1]-p[1];l=math.hypot(dx,dz);yaw=math.atan2(dx,dz)
  for t in np.linspace(0,1,max(2,math.ceil(l/.2))):
   x,z=p[0]+dx*t,p[1]+dz*t;y=aa['y']+(bb['y']-aa['y'])*t
   c=corridor(x,z,y);body=poly(x,z,yaw);checks+=1
   if not c.covers(body):fails.append([name,a,b,float(t)])
   if prev:maxstep=max(maxstep,abs(y-prev))
   prev=y
# Dense lateral motion into a rail. A sweep is evaluated at <=.1 m travel and <=1 degree rotation.
def sweep(start,end):
 travel=math.hypot(end[0]-start[0],end[1]-start[1]);angle=abs(end[3]-start[3]);n=max(1,math.ceil(travel/.1),math.ceil(angle/math.radians(1)))
 safe=start
 for i in range(1,n+1):
  t=i/n;q=tuple(a+(b-a)*t for a,b in zip(start,end))
  if not corridor(*q[:3]).covers(poly(q[0],q[1],q[3])):return safe,True,n
  safe=q
 return safe,False,n
rail=[]
for name,r in m['routes'].items():
 active_edges=set(zip(r['nodes'],r['nodes'][1:]));ns=r['nodes'];a,b=ns[len(ns)//2:len(ns)//2+2];aa,bb=nodes[a],nodes[b];p,q=aa['p'],bb['p'];dx,dz=q[0]-p[0],q[1]-p[1];l=math.hypot(dx,dz);yaw=math.atan2(dx,dz);x,z=(p[0]+q[0])/2,(p[1]+q[1])/2;y=(aa['y']+bb['y'])/2
 for sign in [-1,1]:
  start=(x,z,y,yaw);end=(x+sign*dz/l*15,z-sign*dx/l*15,y,yaw);safe,blocked,n=sweep(start,end);rail.append({'route':name,'side':sign,'blocked':blocked,'acceptedDisplacement':math.dist(start[:2],safe[:2]),'substeps':n})
assert not fails,fails[:3]
assert all(r['blocked'] for r in rail)
result={'scope':'Standalone sampled body-containment feasibility only. Not continuous collision proof or game test.','gameHalfWidth':HALF_WIDTH,'testBodyHalfWidth':HALF_BODY,'testBodyHalfLength':HALF_LENGTH,'centerlineBodyPoses':checks,'bodyFailures':len(fails),'maxSampleHeightStep':maxstep,'railSweeps':rail,'heightAwareLocalCorridor':True,'routeIdentityGuard':True,'branchSwitchingTested':False}
json.dump(result,open('/tmp/domlur-surface-prototype/containment-results.json','w'),indent=2);print(json.dumps(result,indent=2))
