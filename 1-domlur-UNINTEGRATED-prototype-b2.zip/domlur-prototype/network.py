import json,math,heapq,collections
m=json.load(open('/tmp/deep-research/domlur/merged-map.json'));roads=m['roads'];sel=[w for w in roads if 'Domlur Flyover' in w['tags'].get('name','') or w['id']=='27227959'];ids={w['id'] for w in sel};nodes={n:p for w in sel for n,p in zip(w['nodes'],w['p'])};adj=collections.defaultdict(list);direct=collections.defaultdict(list)
for w in sel:
 for a,b in zip(w['nodes'],w['nodes'][1:]):
  d=math.dist(nodes[a],nodes[b]);adj[a].append((b,d));adj[b].append((a,d));direct[a].append((b,d,w['id']))
external={n for w in roads if w['id'] not in ids and w['tags'].get('highway') not in ['footway','path','cycleway','steps','pedestrian'] for n in w['nodes'] if n in nodes};dist={n:0 for n in external};q=[(0,n) for n in external];heapq.heapify(q)
while q:
 d,n=heapq.heappop(q)
 if d!=dist[n]:continue
 for b,dd in adj[n]:
  if d+dd<dist.get(b,1e99):dist[b]=d+dd;heapq.heappush(q,(d+dd,b))
def y(n):
 t=min(1,dist[n]/90);return 6.8*t*t*(3-2*t)
# Shortest actual legal route on the selected directed graph.
def path(a,b):
 d={a:0};prev={};q=[(0,a)]
 while q:
  at,n=heapq.heappop(q)
  if n==b:break
  if at!=d[n]:continue
  for nn,dd,id in direct[n]:
   if at+dd<d.get(nn,1e99):d[nn]=at+dd;prev[nn]=(n,id);heapq.heappush(q,(at+dd,nn))
 if b not in d:return None
 ns=[b];ws=[]
 while ns[-1]!=a:
  n,id=prev[ns[-1]];ns.append(n);ws.append(id)
 return {'length':d[b],'nodes':ns[::-1],'wayIds':list(dict.fromkeys(ws[::-1]))}
routes={}
for name,a,b in [('southbound','286654943','12067366799'),('northbound','12067366800','286654942'),('airport_to_north','286681951','286654942')]:
 if a in nodes:routes[name]=path(a,b)
# Recover south start using known way rather than label guess.
south=next(w for w in sel if w['id']=='1286537540');routes['southbound']=path(south['nodes'][0],'12067366799')
branches={n for n in nodes if len(adj[n])>2}
out={'scope':'Isolated game-only geometry, not surveyed elevation or finished feature','height':6.8,'ramp':90,'externalGroundNodes':sorted(external),'routes':routes,'nodes':{n:{'p':p,'distanceToGround':dist[n],'y':y(n),'branch':n in branches} for n,p in nodes.items()},'ways':sel,'sharedJunctions':len(branches),'allNodeHeightsFinite':all(math.isfinite(y(n)) for n in nodes)}
json.dump(out,open('/tmp/domlur-surface-prototype/network.json','w'),indent=2)
print(json.dumps({k:v for k,v in out.items() if k not in ['nodes','ways']},indent=2))
# Count shared-node disagreement under previous independent per-route profiles.
print('external',[(n,nodes[n]) for n in external]);print('branch elevations',[(n,round(y(n),3)) for n in branches])
