import fs from 'node:fs';
export const net=JSON.parse(fs.readFileSync(new URL('./network.json',import.meta.url)));
export const edges=[],out=new Map();
for(const w of net.ways)for(let i=1;i<w.nodes.length;i++){
 const a=w.nodes[i-1],b=w.nodes[i],p=net.nodes[a],q=net.nodes[b],len=Math.hypot(q.p[0]-p.p[0],q.p[1]-p.p[1]);
 const e={id:edges.length,a,b,p,q,len,way:w.id};edges.push(e);if(!out.has(a))out.set(a,[]);out.get(a).push(e.id);
}
export function pose(st){const e=edges[st.edge],t=st.s/e.len;return{x:e.p.p[0]+(e.q.p[0]-e.p.p[0])*t,z:e.p.p[1]+(e.q.p[1]-e.p.p[1])*t,y:e.p.y+(e.q.y-e.p.y)*t};}
export function advance(st,ds,next){
 const history=[...(st.history||[])],e=edges[st.edge],at=st.s+ds;
 if(at>=0&&at<=e.len)return{edge:st.edge,s:at,history};
 if(at<0){const prev=history.pop();if(prev===undefined||edges[prev].b!==e.a)return null;const s=edges[prev].len+at;if(s<0)throw Error('subdivide movement');return{edge:prev,s,history};}
 if(!out.get(e.b)?.includes(next))return null;
 const rest=at-e.len;if(rest>edges[next].len)throw Error('subdivide movement');history.push(e.id);return{edge:next,s:rest,history};
}
export function attach(node){if(!net.externalGroundNodes.includes(node))return null;return out.get(node)?.map(edge=>({edge,s:0,history:[]}))||[];}
