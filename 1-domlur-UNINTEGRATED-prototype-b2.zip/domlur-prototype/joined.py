import json,math
import numpy as np
from shapely.geometry import LineString,Polygon
from shapely.ops import triangulate
m=json.load(open('/tmp/domlur-surface-prototype/network.json'));nodes=m['nodes'];routes={};halfwidth=3.3
# Route-scoped polygon triangulation: same boundary used for rendered road and body containment.
# Provisional narrower width avoids the earlier paired-carriageway overlap. NOT real survey width.
for name,r in m['routes'].items():
 pts=[nodes[n]['p'] for n in r['nodes']];ys=[nodes[n]['y'] for n in r['nodes']];line=LineString(pts);poly=line.buffer(halfwidth,cap_style=1,join_style=1,quad_segs=8)
 def height(p):
  best=(float('inf'),0)
  for i,(a,b) in enumerate(zip(pts,pts[1:])):
   dx,dz=b[0]-a[0],b[1]-a[1];l2=dx*dx+dz*dz;t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dz)/l2));d=math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dz)
   if d<best[0]:best=(d,ys[i]+(ys[i+1]-ys[i])*t)
  return best[1]
 ts=[t for t in triangulate(poly) if poly.covers(t)];area=sum(t.area for t in ts);assert abs(area-poly.area)<1e-6
 bodyFails=0;poses=0
 for a,b in zip(pts,pts[1:]):
  dx,dz=b[0]-a[0],b[1]-a[1];l=math.hypot(dx,dz);ux,uz=dx/l,dz/l
  for t in np.linspace(0,1,max(2,math.ceil(l/.2))):
   x,z=a[0]+dx*t,a[1]+dz*t;body=Polygon([(x+u*ux+v*uz,z+u*uz-v*ux) for u,v in[(-1.4,-.8),(1.4,-.8),(1.4,.8),(-1.4,.8)]])
   poses+=1;bodyFails+=not poly.covers(body)
 fine=[];pending=[list(t.exterior.coords)[:3] for t in ts]
 while pending:
  tri=pending.pop();lengths=[math.dist(tri[i],tri[(i+1)%3]) for i in range(3)];i=max(range(3),key=lambda i:lengths[i])
  if lengths[i]>2:
   a,b,c=tri[i],tri[(i+1)%3],tri[(i+2)%3];mid=((a[0]+b[0])/2,(a[1]+b[1])/2);pending.extend([[a,mid,c],[mid,b,c]])
  else:fine.append(tri)
 maxerr=max(abs(sum(height(p) for p in tri)/3-height((sum(p[0] for p in tri)/3,sum(p[1] for p in tri)/3))) for tri in fine)
 routes[name]={'heightCentroidMaxError':maxerr,'triangleCount':len(fine),'boundary':list(poly.exterior.coords),'triangles':[[[x,height((x,z)),z] for x,z in t] for t in fine],'area':area,'poses':poses,'bodyFailures':bodyFails,'points':[[*p,ys[i]] for i,p in enumerate(pts)]}
assert not any(r['bodyFailures'] for r in routes.values())
result={'scope':'Route-scoped joined deck prototype; no game acceptance','gameHalfWidth':halfwidth,'bodyHalfLength':1.4,'bodyHalfWidth':.8,'routes':routes}
json.dump(result,open('/tmp/domlur-surface-prototype/joined.json','w'))
print({n:{k:v for k,v in r.items() if k in ['area','poses','bodyFailures']} for n,r in routes.items()})
