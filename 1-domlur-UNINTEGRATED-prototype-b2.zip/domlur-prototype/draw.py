import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
m=json.load(open('/tmp/domlur-surface-prototype/network.json'));ns=m['nodes'];fig,(ax,bx)=plt.subplots(1,2,figsize=(14,8),gridspec_kw={'width_ratios':[1.2,1]})
lines=[];ys=[]
for w in m['ways']:
 for a,b in zip(w['nodes'],w['nodes'][1:]):lines.append([ns[a]['p'],ns[b]['p']]);ys.append((ns[a]['y']+ns[b]['y'])/2)
lc=LineCollection(lines,cmap='viridis',linewidths=4);lc.set_array(ys);lc.set_clim(0,6.8);ax.add_collection(lc);ax.autoscale();ax.invert_yaxis();ax.set_aspect('equal');ax.set_title('Real OSM plan geometry; game-only height colors');ax.set_xlabel('World x (m)');ax.set_ylabel('World z (m, south downward)');fig.colorbar(lc,ax=ax,label='Game height (m), NOT survey')
for n in m['externalGroundNodes']:ax.scatter(*ns[n]['p'],color='black',s=18,zorder=5)
for name,r in m['routes'].items():
 pts=[ns[n]['p'] for n in r['nodes']];s=[0]
 for a,b in zip(pts,pts[1:]):s.append(s[-1]+((a[0]-b[0])**2+(a[1]-b[1])**2)**.5)
 bx.plot(s,[ns[n]['y'] for n in r['nodes']],label=name.replace('_',' '))
bx.set_title('Shared-node profiles prevent ramp seams');bx.set_xlabel('Distance along route (m)');bx.set_ylabel('Game height (m)');bx.legend();bx.grid(alpha=.2)
fig.suptitle('Domlur isolated feasibility prototype - not gameplay or real elevation',fontsize=16)
fig.text(.52,.025,'7,475 centerline body poses: no containment failures\n6 lateral sweeps blocked with route-identity guard\nBranch switching, piers, traffic and camera are not tested',fontsize=11)
fig.tight_layout(rect=[0,.16,1,.95]);fig.savefig('/downloads/domlur-network-containment.png',dpi=140)
