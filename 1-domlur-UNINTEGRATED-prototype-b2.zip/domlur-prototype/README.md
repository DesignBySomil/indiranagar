# Domlur flyover: unintegrated feasibility prototype

Not deployed. Not accepted gameplay. No production/game source changes.

Plan geometry is derived from OpenStreetMap (ODbL), fetched Oct 27, 2026:
- https://www.openstreetmap.org/api/0.6/map?bbox=77.638,12.958,77.645,12.965
- https://www.openstreetmap.org/api/0.6/map?bbox=77.638,12.964,77.645,12.971

Heights (6.8 m), ramp distance (90 m), road half-width (4.8 m), and body size are provisional game values, not surveyed dimensions.

Evidence: network.json retains exact node/way IDs and plan coordinates. state-test.mjs exercises directed support transitions. containment.py exercises sampled body containment, not continuous collision proof. results JSON files preserve bounded results.

Known gaps: reverse predecessor history, steering/branch choice, joined rendered deck geometry (current segment strips show wedge gaps), real rail collision, piers, thickness, height-aware traffic/building queries, recovery, game camera, mobile performance. Current scene is a diagnostic only.

Run state unit tests: node state-test.mjs
Python containment requires numpy and shapely. Scripts currently have local paths that must be adapted after extraction. scene.html uses Three.js modules served by capture.cjs; capture paths must likewise be adapted. No credentials or user data are included.

## Batch 2: reverse and joined route geometry
Reverse predecessor history now passes 117 legal endpoint round-trips; reverse without history rejects. Joined 3-route polygons use provisional 3.3 m half-width. 7,475 centerline body poses pass polygon containment. Adaptive tessellation limits rendered triangle edges to 2 m: 20,827 triangles total. At sampled triangle centroids, height disagreement against support function is <=0.04453 m. This is a diagnostic error bound at those samples, not an everywhere bound. Render covers only three routes, no rails/piers. scene-segment-diagnostic.html preserves the defective first render for comparison. Main game remains unchanged.
