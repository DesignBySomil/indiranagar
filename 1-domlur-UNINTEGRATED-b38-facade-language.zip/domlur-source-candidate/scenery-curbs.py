# Unioned source ground-road edges, no kerb bars across source junctions.
exec(open('scenery-roads.py').read().split('for key,ps')[0])
geom=unary_union(polys).intersection(box(-800,795,800,2250));pos=[]
for p in ([geom]if geom.geom_type=='Polygon'else geom.geoms):
 for ring in [p.exterior,*p.interiors]:
  pts=list(ring.coords)
  for a,b in zip(pts,pts[1:]):
   if abs(a[0])>=799 or abs(b[0])>=799 or min(a[1],b[1])<=796 or max(a[1],b[1])>=2249:continue
   for x,y,z in [(a[0],.055,a[1]),(b[0],.055,b[1]),(a[0],.13,a[1]),(a[0],.13,a[1]),(b[0],.055,b[1]),(b[0],.13,b[1])]:pos.extend([x,y,z])
json.dump({'scope':'Creative game kerbs on unioned OSM ground-road edges, not surveyed sidewalk heights. Visual only outside drivable candidate route.','curbs':pos},open('public/data/domlur-curbs.json','w'));print('curb triangles',len(pos)//9)
