import * as THREE from 'three';
import {nightUniform} from './materials.js';
// Reuse the accepted city facade treatment, on unchanged candidate source envelopes.
export function candidateFacadeMaterial(){
const mat=new THREE.MeshStandardMaterial({vertexColors:true,roughness:.94});
  mat.onBeforeCompile = (sh) => {
    sh.uniforms.uNight = nightUniform;
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', '#include <common>\nvarying vec3 vWp;\nvarying vec3 vWn;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvWp = (modelMatrix * vec4(position, 1.0)).xyz;\nvWn = normalize(mat3(modelMatrix) * normal);');
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', `#include <common>
        uniform float uNight;
        varying vec3 vWp;
        varying vec3 vWn;
        float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      `)
      .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
        if (abs(vWn.y) < 0.45) {
          // Weathering: large patchy tone variation
          float ptch = h21(floor(vWp.xz * 0.11) + 17.0);
          diffuseColor.rgb *= 0.92 + 0.14 * ptch;
          // Vertical rain/grime streaks running down the facade
          float stSeed = h21(vec2(floor((vWp.x * abs(vWn.z) + vWp.z * abs(vWn.x)) * 2.3), 3.7));
          float streak = step(0.78, stSeed) * (0.5 + 0.5 * sin(vWp.y * 1.7 + stSeed * 40.0));
          diffuseColor.rgb *= 1.0 - streak * 0.10;
          // Dusty dark base band near the ground
          float baseBand = smoothstep(1.5, 0.15, vWp.y);
          diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * vec3(0.72, 0.68, 0.62), baseBand * 0.75);
          float horiz = (vWp.x * abs(vWn.z) + vWp.z * abs(vWn.x));
          float floorV = fract(vWp.y / 3.3);
          float bSeed = h21(floor(vWp.xz * 0.04));

          // Cream concrete floor chajja / sunshade ledge & parapet band
          float ledge = smoothstep(0.89, 0.94, floorV);
          diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.92, 0.89, 0.82), ledge * 0.75);

          if (vWp.y > 3.3) {
            float u = horiz / 2.8;
            float v = (vWp.y - 0.3) / 3.3;
            vec2 cell = floor(vec2(u, v));
            vec2 f = fract(vec2(u, v));

            // Balcony rail / terracotta planter band on lower part of upper floors
            float balcBand = step(0.06, f.y) * step(f.y, 0.22) * step(0.10, f.x) * step(f.x, 0.90);
            float balcBars = step(0.45, fract(horiz * 3.5));
            diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.22, 0.24, 0.26), balcBand * balcBars * 0.55);

            // Window frame + warm lit panes
            float win = step(0.20, f.x) * step(f.x, 0.80) * step(0.28, f.y) * step(f.y, 0.78);
            float border = step(0.17, f.x) * step(f.x, 0.83) * step(0.25, f.y) * step(f.y, 0.81) - win;
            diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.95, 0.93, 0.88), clamp(border, 0.0, 1.0) * 0.8);

            float mullion = step(0.48, f.x) * step(f.x, 0.52) + step(0.51, f.y) * step(f.y, 0.55);
            win *= (1.0 - clamp(mullion, 0.0, 1.0));

            float seed = h21(cell + floor(vWp.xz * 0.02));
            float on = step(0.58, seed);
            float wv = h21(cell + 5.3);
            vec3 warm = mix(vec3(1.0, 0.58, 0.22), vec3(1.0, 0.78, 0.42), wv) * (0.55 + 0.6 * h21(cell + 9.1));

            totalEmissiveRadiance += warm * win * on * (0.08 + uNight * 0.50);
            diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.24, 0.30, 0.36), win * (1.0 - uNight * 0.6) * 0.65);
          } else {
            // Ground floor striped shopfront awning band (y = 2.45m to 3.15m)
            float awningBand = step(2.45, vWp.y) * step(vWp.y, 3.15);
            float stripe = step(0.5, fract(horiz * 2.2));
            vec3 awColA = bSeed > 0.6 ? vec3(0.82, 0.22, 0.18) : (bSeed > 0.3 ? vec3(0.12, 0.48, 0.28) : vec3(0.16, 0.36, 0.68));
            vec3 awCol = mix(awColA, vec3(0.96, 0.94, 0.88), stripe);
            diffuseColor.rgb = mix(diffuseColor.rgb, awCol, awningBand * 0.92);

            // Ground floor shopfront windows & shutters below awning
            float shopU = fract(horiz / 4.0);
            float shutter = step(0.12, shopU) * step(shopU, 0.88) * step(0.08, vWp.y) * step(vWp.y, 2.38);
            float shopLit = step(0.45, h21(floor(vec2(horiz / 4.0, 1.0))));
            vec3 shopGlass = mix(vec3(0.32, 0.35, 0.38), vec3(1.0, 0.82, 0.48), shopLit * (0.35 + 0.65 * uNight));
            diffuseColor.rgb = mix(diffuseColor.rgb, shopGlass, shutter * 0.75);
            totalEmissiveRadiance += vec3(1.0, 0.78, 0.42) * shutter * shopLit * (0.18 + uNight * 0.75);
          }
        }
      `);
  };

return mat;
}
