# Unintegrated batch38: accepted facade language and joined kerbs

Replaced the candidate's repeated flush-window art with the accepted city facade shader, applied to unchanged candidate source footprint/height envelopes. Window frames, balcony bands, awning bands, weathering and night treatment now use the same visual language without changing accepted city source. Building geometry merged into one facade mesh.

Source-ground-road kerbs are built on the union boundary, so they do not add bars across source junctions. Visual outside candidate driving support. Initial shoulder layer covered road asphalt; pixel inspection caught it, restored shoulder below asphalt and re-rendered. Noon drive curve200m and transition1000m inspected after correction. Continuous side ground road remains visible, city facade transition better matched. Elevated terrain still too sparse, no overall acceptance.

No source building footprints/heights or candidate driving support changed. No physical-device acceptance or production/accepted-source changes. Local patch not remotely preserved yet.
