# Unintegrated batch40: combined scenery recheck

Main candidate load now returns existing routes when already loaded, preventing repeated explicit loads from duplicating the complete scenery. Concurrent first-load race not addressed by this guard.

After the park/accepted-tree/facade/ground-road changes, full ramp and southbound actual main-physics movers-on drives with normal three-mode camera blends re-ran: identical traces, allnodes, zero movementblocks/candidate-camera-point overlaps. Northbound rerun hit the local browser protocol timeout, so its earlier pass is not a fresh combined check. Detailed-tree/scenery addition increases test runtime; no real-device performance claim.

Park/fence/bench geometry is15m excluded from route corridors but not integrated as an off-route physics world; the extension still supports only its named route corridors. All-ray/near-plane/actors/accepted-decoration/device acceptance remain open. No accepted source/deployment change. Local patch not remote yet.
