# Creative game supports, not an engineering/survey layout. Exclude source roads/footprints.
import json,math
from shapely.geometry import LineString,Point,Polygon
m=json.load(open('/tmp/deep-research/domlur/merged-map.json'));d=json.load(open('public/data/domlur-candidate.json'));b=json.load(open('public/data/domlur-buildings-game.json'));roads=[LineString(w['p']) for w in m['roads']if len(w.get('p',[]))>1 and w['tags'].get('layer','0')=='0' and 'Flyover'not in w['tags'].get('name','')];polys=[Polygon(w['points'])for w in b['buildings']];piers=[];skipped=0
for name,r in d['routes'].items():
 total=0;nextAt=25
 for n1,n2 in zip(r['nodes'],r['nodes'][1:]):
  a,c=d['nodes'][n1],d['nodes'][n2];L=math.dist(a['p'],c['p'])
  while nextAt<total+L:
   t=(nextAt-total)/L;x,z=[a['p'][i]+(c['p'][i]-a['p'][i])*t for i in range(2)];y=a['y']+(c['y']-a['y'])*t;p=Point(x,z)
   if y>4.5 and not any(s.distance(p)<5 for s in roads) and not any(q.distance(p)<1.2 for q in polys):piers.append({'x':x,'z':z,'radius':.6,'bottom':0,'top':y-.4,'route':name})
   else:skipped+=1
   nextAt+=30
  total+=L
json.dump({'scope':'Creative game-only pier layout; source-road and building-footprint exclusions, not engineering.','piers':piers,'skipped':skipped},open('public/data/domlur-piers.json','w'));print({'piers':len(piers),'skipped':skipped})
