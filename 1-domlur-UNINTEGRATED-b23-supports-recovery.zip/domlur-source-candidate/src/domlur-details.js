import * as THREE from 'three';
export function renderDomlurDetails(data,joined,scene){
 const group=new THREE.Group();group.name='Candidate game-only supports and road markings';
 const mat=new THREE.MeshStandardMaterial({color:0xa9a99e,roughness:.9});
 for(const p of data.piers){const m=new THREE.Mesh(new THREE.CylinderGeometry(p.radius,p.radius,p.top-p.bottom,10),mat);m.position.set(p.x,(p.top+p.bottom)/2,p.z);m.castShadow=true;m.receiveShadow=true;group.add(m);}
 const positions=[];
 for(const r of Object.values(joined.routes)){let next=5,total=0;for(let i=1;i<r.points.length;i++){const a=r.points[i-1],b=r.points[i],L=Math.hypot(b[0]-a[0],b[1]-a[1]);while(next+2<L+total){if(next>=total){for(const s of[next,next+2]){const t=(s-total)/L;positions.push(a[0]+(b[0]-a[0])*t,a[2]+(b[2]-a[2])*t+.035,a[1]+(b[1]-a[1])*t);}}next+=7;}total+=L;}}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));group.add(new THREE.LineSegments(g,new THREE.LineBasicMaterial({color:0xe6dfc5})));scene.add(group);return group;
}
export function pierContact(data,x,z,y,roof=2.2){return data?.piers.some(p=>y<=p.top&&y+roof>=p.bottom&&(x-p.x)**2+(z-p.z)**2<p.radius**2)||false;}
